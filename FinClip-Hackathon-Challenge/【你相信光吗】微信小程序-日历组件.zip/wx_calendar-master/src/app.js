App({
  onLaunch: function() {}
})
