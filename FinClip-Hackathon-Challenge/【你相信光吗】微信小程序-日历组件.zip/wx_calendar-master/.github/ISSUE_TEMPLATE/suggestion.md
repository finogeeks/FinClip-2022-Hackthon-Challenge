---
name: 功能建议
about: 关于组件功能的建议
title: ''
labels: suggestion
assignees: treadpit

---

**功能建议**
你期望提供或修改什么功能

**需求背景**
描述是什么场景下需要支持该功能
