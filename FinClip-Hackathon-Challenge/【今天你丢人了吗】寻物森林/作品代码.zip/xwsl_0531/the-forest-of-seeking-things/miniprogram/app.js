//app.js
// var plugin = requirePlugin("chatbot");

App({
  onLaunch: function () {
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        env: 'cloud1-2g7s81h60f3fd184',
        traceUser: true,
      })
    }

    this.globalData = {}
    // wx.getStorage({
    //   key:'p_openid',
    //   success(res){
    //     console.log(res.data)
    //     var openid = res.data
    //     wx.getStorage({
    //       key:"user",
    //       success(res){
    //         console.log(openid,res.data.avatarUrl,res.data.nickName)
    //         var avatarUrl=res.data.avatarUrl
    //         var nickName = res.data.nickName
    //         var appid = "bYbdPwlqVyjk8D49BkjxtfJZnJuHYe"
    //         plugin.init({
    //           appid: appid, //小程序示例账户，仅供学习和参考
    //           openid: openid, //用户的openid，必填项，可通过wx.login()获取code，然后通过后台接口获取openid
    //           userHeader: avatarUrl, // 用户头像
    //           userName: nickName, // 用户昵称
    //           anonymous: false, // 是否允许匿名用户评价，默认为false，设为ture时，未传递userName、userHeader两个字段时将弹出登录框
    //           guideList: ["中午吃啥呢"],
    //           success: () => {}, //非必填
    //           fail: (error) => {}, //非必填
    //       });
    //       plugin.send({
    //       query: "你好",
    //       success: res => {
    //         console.log(res);
    //       },
    //       fail: error => {}
    //     });


    //       }
    //     })
    //   }
    // })
 
  },

  // 获取Openid
  getOpenid() {
    wx.cloud.callFunction({
      name:"getopenid"
    }).then(res=>{
      console.log("获取openid成功",res.result.event.userInfo.openId)
      this.setData({
        list:res.result.event.userInfo.openId
      })
    }).catch(err=>{
      console.log("获取失败",err)
    })
  },
})
