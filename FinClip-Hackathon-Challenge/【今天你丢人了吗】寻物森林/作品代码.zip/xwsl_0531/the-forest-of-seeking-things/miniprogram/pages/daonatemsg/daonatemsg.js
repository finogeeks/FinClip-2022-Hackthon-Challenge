// pages/daonatemsg/daonatemsg.js
const DB = wx.cloud.database({
  env: 'cloud1-2g7s81h60f3fd184'
}).collection("daonate")

let daonate_name=""
let daonate_person=""
let daonate_phone=""
let daonate_address=""
var pic_list = new Array();
let pic1 = ""

Page({

  data: {

  },

  //获取用户输入的信息
  input_name(e){
    console.log(e.detail.value)
     daonate_name = e.detail.value
},
input_person(e){
  console.log(e.detail.value)
   daonate_person = e.detail.value
},
input_phone(e){
  console.log(e.detail.value)
   daonate_phone = e.detail.value
},
input_address(e){
  console.log(e.detail.value)
   daonate_address = e.detail.value
},

// 添加数据
addData(){
  wx.showLoading({
    title: "提交中",
  })
  if(daonate_name=='' || daonate_name==null || daonate_person=="" || daonate_person==null || daonate_phone=='' || daonate_phone==null || daonate_address=='' || daonate_address==null || pic_list[0]=='' || pic_list[0]==null) {
    wx.showToast({
      title: '所有信息都要填写哟~',
      icon: 'none',
      duration: 2000     
    })
  } else {
    DB.add({
      data:{
        daonate_name:daonate_name,
        daonate_person:daonate_person,
        daonate_phone:daonate_phone,
        daonate_address:daonate_address,
        pic1:pic_list[0],
      },
      success(res){
        console.log("添加成功",res)
        wx.showToast({
          title: '提交成功',
          icon: 'success',
          duration: 2000
          })
        wx.reLaunch({
          url:"/pages/timeline/timeline",       
        })
      },
      fail(res){
        console.log("添加失败",res)
        wx.showToast({
          title: '提交失败',
          icon: 'error',
          duration: 2000
          })
      },
      
    })
  }

},

pic_api: function(e){    // 这里的imageData是图片转换成base64格式的数据
  var that = this;
  const detectUrl = `https://aip.baidubce.com/api/v1/solution/direct/imagerecognition/combination?access_token=${that.data.baiduToken}`    // baiduToken是已经获取的access_Token
  // console.log('123',detectUrl) 
    return new Promise(function(resolve,reject){        
    wx.request({            
      url: detectUrl,            
      data: {                
        image: e,
        scenes:["advanced_general","multi_object_detect"],       
      },            
      method: 'POST',            
      dataType: 'json',            
      header:{                
        'content-type': 'application/json'    // 必须的        
      },            
      success: function(res, resolve){              
        console.log('调用图像识别APIsuccess：',res.data);              
        // var word = res.data.words_result[0].words              	
        // console.log(word);            
      },            
      fail : function(res,reject){              
        console.log('调用图像识别APIfail：',res.data);           			},            

    })
  }) 
},

//上传图片
f0: function(event){
  let that = this;
  var that_ = this;

  wx.chooseImage({
    count: 1,
    sizeType: ['original', 'compressed'],
    sourceType: ['album', 'camera'],
    success: function(res){
      console.log("选择成功",res)
      that_.setData({
        src:res.tempFilePaths[0],
        src_list:res.tempFilePaths,
        judge:res.tempFilePaths["length"]
       })
       that.pic_api(that.data.src_list[0])

      var src_list=res.tempFilePaths
      // var judge=res.tempFilePaths["length"]
      console.log("src_list",src_list)
      src_list.forEach((item,idx)=>{
        var fileName=Date.now()+"_"+idx;
        that.uploadImg(fileName,item)
      })
    },
  })
},

//上传图片到云开发
uploadImg(fileUrl,path){
  wx.cloud.uploadFile({
    cloudPath: fileUrl+'example.png', // 上传至云端的路径
    filePath: path, // 小程序临时文件路径
    success: res => {
      // 返回文件 ID
      pic_list.push(res.fileID)
      console.log("上传成功",res)
      console.log("照片列表",pic_list)
      pic_list.forEach((item,idx)=>{
        var pic_idx = pic_list[idx]
        console.log("数组元素",pic_idx)
      })
      this.setData({
        pic: res.fileID
      })
      
    },
    fail: console.error
  })
},

//点击预览图片
  f1:function(event){
    // var that_=this;
    // var src = event.currentTarget.dataset.src;//获取data-src
    // var imgList = that_.data.imgUrls;//获取data-list
    wx.previewImage({
      current: pic_list[0], // 当前显示图片的http链接
      urls: pic_list, // 需要预览的图片http链接列表
      success:function(res){
        console.log("1111",res)
      }
    })
  },


  onLoad: function (options) {

  },

  onReady: function () {

  },

  onShow: function () {

  },

  onHide: function () {

  },

  onUnload: function () {

  },

  onPullDownRefresh: function () {

  },

  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})