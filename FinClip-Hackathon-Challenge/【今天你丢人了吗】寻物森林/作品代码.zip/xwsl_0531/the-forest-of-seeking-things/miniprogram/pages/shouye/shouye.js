const createRecycleContext = require('miniprogram-recycle-view')

const db = wx.cloud.database({
  env: 'cloud1-2g7s81h60f3fd184'
})

Page({
  data: {
    show1 : false,
    show2 : false,
    show3 : false,
    tab_icon:[
      {
        image:"https://636c-cloud-m01-t5i5m-1304238103.tcb.qcloud.la/images/%E6%84%9F%E8%B0%A2%E4%BF%A1.png?sign=f7d37c7e2752541d3da0c1ace4801ec0&t=1621178866",
        title:"＋感谢信"
      },
      {
        image:"https://636c-cloud-m01-t5i5m-1304238103.tcb.qcloud.la/images/%E5%A5%BD%E4%BA%BA%E5%A5%BD%E4%BA%8B.png?sign=ab6b0234a579d48f142bdfdad61f44bb&t=1621178884",
        title:"＋好人好事"
      },
      {
        image:"https://636c-cloud-m01-t5i5m-1304238103.tcb.qcloud.la/images/%E5%AF%BB%E7%89%A9%E5%90%AF%E4%BA%8B.png?sign=6d521e7ab9157b6118d2b86955aad828&t=1620832379",
        title:"＋公益捐赠"
      }
    ],
    list:[],
    lost_data:"失物日期",
    lost_place:"失物地点",
    lost_type:"失物类别",
    array1:[],
    array2:['一教','二教','三教','...'],//'西区','中区','东区'?
    array3:['手机','饭卡','...'],
    imgUrls: [
      'https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/swiper3.png?sign=939d46aea5273421576c25f634c0de8d&t=1622182783',
      'https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/swiper2.png?sign=cac3d942e06b2b44589790ecf7202187&t=1622182636',
      'https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/swiper1.png?sign=92411e8e559441bc1e1d461114c46b74&t=1622182671',
    ],
    current: 0,
    animationData: {},
    animationData2: {},
    Banner_Tweet:{}
  },

  // 筛选X3

  bindPickerChange1:function(e){
    var that = this;
    console.log('picker1发送选择改变，携带值为', e.detail.value)
    var lost_data = e.detail.value
    console.log('lost_data值为', lost_data)
    this.setData({
      lost_data: e.detail.value,  
    })
  },

  bindPickerChange2: function (e) {
    var that = this;
    // console.log('picker2发送选择改变，携带值为', e.detail.value)
    var lost_place = that.data.array2[e.detail.value]
    console.log('lost_place值为', lost_place)
    this.setData({
      lost_place: that.data.array2[e.detail.value],
    })
  },
  bindPickerChange3: function (e) {
    var that = this;
    // console.log('picker3发送选择改变，携带值为', e.detail.value)
    var lost_type = that.data.array3[e.detail.value]
    console.log('lost_type值为', lost_type)
    this.setData({
      lost_type: that.data.array3[e.detail.value],    
    })
  },

  onLoad: function (options) {
    this.getup()
    this.get_Btweet()
    // this.getSimilarity()
  },

  onShow(){
    // this.getup()
  },

  //上拉触底加载
  onReachBottom() {
    this.getup()
  },

  onReady() {
    var ctx = createRecycleContext({
      id: 'recycleId',
      dataKey: 'list',
      page: this,
      itemSize: { // 这个参数也可以直接传下面定义的this.itemSizeFunc函数
        width: 354.81,
        height: 152
      }
    })
    // ctx.append(newList)
    // ctx.update(beginIndex, list)
    // ctx.destroy()
  },
  
  itemSizeFunc: function (item, idx) {
    return {
        width: 162,
        height: 182
    }
  },

  detail(e) {
    console.log(e)
    console.log('物品id',e.currentTarget.dataset.id)
    wx.navigateTo({
      url: '/pages/sw_detail/sw_detail?id=' + e.currentTarget.dataset.id,
    })
  },

  //云函数突破数据限制
  getup() {
    wx.showLoading({
      title: '加载中',
    })
    let len = this.data.list.length
    console.log("当前list长度",len)
    wx.cloud.callFunction({
      name:'sy_up',
      data: {
        len:len,
        pageNum:40,
      }
    }).then(res=>{
      wx.hideLoading()
      console.log('调用成功',res)
      let datalist = res.result.data
      if (datalist.length <=0) {
        wx.showToast({
          icon:'none',
          title: '没有更多数据了',
        })
      }
      this.setData({
        list: this.data.list.concat(datalist)
      })
      console.log("显示",this.data.list)
    }).catch(err=>{
      wx.hideLoading()
      console.log('调用失败',err)
    })
  },

  // 搜索
 searchList: function(ev){
  console.log('输入框内容?')
  let e = ev.detail;
  this.data.searchstr = e.detail.value
  console.log(this.data.searchstr,'输入框内容')
  var searchstr = this.data.searchstr //获取输入框输入内容
  this.setData({
    searchstr: e.detail.value
  })
 },//监听输入框内容

 endsearchList(e) {
  console.log('搜索框回调函数')
  db.collection('try_5-10')
  .where({
    name:{
      $regex:'.*'+ this.data.searchstr,
      $options: 'i'
    } //匹配输入内容
  })
  .get({
    success : res =>{
      if (res.data.length == 0) {
        wx.showModal({
          title: '提示',
          content: '暂时没找到对应答案',
          showCancel: false,
          success: function (res) { }
        })
        return;
      }
      else{
        console.log('[搜索成功]',res)
      }
      this.setData({
        data : res.data
       })
       wx.navigateTo({
        url: '/pages/search result/search result?name=' + this.data.searchstr,
      })
     }
   })
},//搜索回调

// 取消搜索
cancelsearch() {
  this.setData({
    searchstr: ''
  })
},

//清空搜索框
activity_clear(e) {
  this.setData({
    searchstr: ''
  })
},

gooddeed() {
  var that = this
  that.setData({
    show1 : true
  })
  // setTimeout(function () {
    that.navigt1()
  //  }, 1000)
  // wx.navigateTo({
  //   url: '/pages/goodmsg/goodmsg',
  //   success:()=>{
  //     this.setData({
  //       show : false
  //     })
  //   },
  // })
},

navigt1(e){
  wx.navigateTo({
    url: '/pages/goodmsg/goodmsg',
    success:()=>{
      this.setData({
        show1 : false
      })
    },
  })
},

donations() {
  var that = this
  that.setData({
    show3 : true
  })
  // setTimeout(function () {
    that.navigt3()
  //  }, 1000)
},
navigt3(e){
  wx.navigateTo({
    url: '/pages/timeline/timeline',
    success:()=>{
      this.setData({
        show3 : false
      })
    },
  })
},



//下拉刷新
onRefresh(){
  this.getup()
  //在当前页面显示导航条加载动画
  wx.showNavigationBarLoading(); 
  wx.showLoading({
    title: '刷新中...',
  })
  this.refresh_Data();
},

refresh_Data(){
  wx.request({
      url: '',
      complete(res){
      wx.hideLoading();
      wx.hideNavigationBarLoading();
      wx.stopPullDownRefresh();
    }
  })   
},

onPullDownRefresh: function () {
  this.onRefresh();
},

ranking() {
  var that = this
  that.setData({
    show2 : true
  })
  // setTimeout(function () {
      that.navigt2()
  //  }, 1000)

  // wx.navigateTo({
  //   url: '/pages/tabs/tabs',
  // })
  // wx.request({
  //   url: 'https://xuzhichao.cn/Azure_CV_API', //仅为示例，并非真实的接口地址
  //   data: {
  //   },
  //   method: 'POST',  
  //   header: {
  //     'content-type': 'application/json' // 默认值
  //   },
  //   success (res) {
  //     console.log(res.data)
  //   }
  // })
},

navigt2(){
  wx.navigateTo({
    url: '/pages/tabs/tabs',
    success:()=>{
      this.setData({
        show2 : false     
       })
    },
  })
},

go_tweet1:function(e) {
  var id = e.currentTarget.dataset.id;
  console.log("目标推文",id)
  console.log("bt",this.data.Banner_Tweet)
  if (id =="2d44d6c2610e82e103773d0d129d3720") {
    wx.navigateTo({
      url: '/pages/tweet/tweet?url=' + this.data.Banner_Tweet[0].t_url,
    })
  }
  if (id=="8937eaa9610e83b9032342b823c4a8b6") {
    wx.navigateTo({
      url: '/pages/tweet/tweet?url=' + this.data.Banner_Tweet[1].t_url,
    })
  }
  if (id=="2d44d6c2610e84340377c1f93b26166d") {
    wx.navigateTo({
      url: '/pages/tweet/tweet?url=' + this.data.Banner_Tweet[2].t_url,
    })
  }
},

// go_tweet2:function(e) {
//   wx.navigateTo({
//     url: '/pages/tweet/tweet?url=' + "https://mp.weixin.qq.com/s/7bs2M-lzO7yQQZKDHGkatg",
//   })
// },

// go_tweet3:function(e) {
//   wx.navigateTo({
//     url: '/pages/tweet/tweet?url=' + "https://mp.weixin.qq.com/s/zgtNQbcK6Xl1I2TTNfSYEQ",
//   })
// },


onShareAppMessage() {
  wx.showShareMenu({
    withShareTicket: true,
    menus: ['shareAppMessage', 'shareTimeline']
  })
},

onShareTimeline(e) {
  console.log(e)
  return {
    title: '分享卡片',
    path:''
  }
},

//文本对比输出相似度
getSimilarity() {
  let str1 = "12301924192470"
  let str2 = "12301924192"
  let sameNum = 0
  //寻找相同字符
  for (let i = 0; i < str1.length; i++) {
      for(let j =0; j< str2.length; j++){
          if(str1[i]===str2[j]){
              sameNum ++ 
              break
          }
      }
  }
  let length = str1.length > str2.length ? str1.length : str2.length
  let result =  (sameNum/length) * 100 || 0
  console.log("相似值",result)
},

get_Btweet() {
  db.collection("Tweet")
  .where({
    t_location:"Banner"
  })
  .get()
  .then(res=>{
    console.log("推文获取成功",res)
    this.setData({
      Banner_Tweet:res.data
    })
  })
  .catch(err=>{
    console.log("获取失败",err)
  })
},

})
    




