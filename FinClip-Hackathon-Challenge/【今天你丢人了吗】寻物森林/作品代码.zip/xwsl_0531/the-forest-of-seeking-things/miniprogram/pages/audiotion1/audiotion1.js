// var content =''
const db = wx.cloud.database({
  env: 'cloud1-2g7s81h60f3fd184'
})

Page({
  data: {
    list:{},
    good:{},
    show:false,//控制下拉列表的显示隐藏，false隐藏、true显示
    selectData:['时间','8:00am','10:00am','12:00am','2:00pm','4:00pm','6:00pm','8:00pm','10:00pm'],//下拉列表的数据
    index:0,//选择的下拉列表下标
    content_css:[],
    search_result:false,
    all_result:true,
    },


    f1:function(e){
      var currentUrl = e.currentTarget.dataset.item;
      console.log(currentUrl);
      // let currentUrl = this.data.list.pic1;
      var dataArray = [];
      dataArray[0] = currentUrl
      wx.previewImage({
         current: dataArray[0], // 当前显示图片的http链接
         urls: dataArray, // 需要预览的图片http链接列表
        success:function(res){
          console.log("1111",res)
        },
        fail(err) {
          console.log("错误反馈",err)
          console.log("currentUrl:",currentUrl)
        }
        
      })
    },


    back(e){
      this.setData({
        all_result:true,
        search_result:false
      })
      this.activity_clear(e)
    },
    

// 调出内置地图：
map(){
  wx.openLocation({
    longitude:113.679750,
    latitude:23.630880,
    scale: 18
  })  
},

    // 点击下拉显示框
    selectTap(){
    this.setData({
     show: !this.data.show
    });
    },
    // 点击下拉列表
    optionTap(e){
    let Index=e.currentTarget.dataset.index;//获取点击的下拉列表的下标
    this.setData({
     index:Index,
     show:!this.data.show
    });
    },
    onLoad(options) {
      console.log(options)
      var content = options.store
      console.log("map传值",options.store)
      // if (options.store=='中饭'){
      //   this.setData({
      //   content : '中饭',
      //   content_css:'zhongfan'
      // })
      // }
      // if(options.store=='图书馆'){
      //   this.setData({
      //     content : '图书馆',
      //     content_css:'tushuguang'
      //   })
      // }
      // if(options.store=='一教'){
      //   this.setData({
      //     content : '一教',
      //     content_css:'yijiao'
      //   })
      // }
      
      this.getlist(content)
    },

    getlist(e) {
     console.log('位置',e)
      db.collection('lost_storage').where({
        store:e,
      })
      .get()
      .then(res => {
        console.log('添加成功',res)
        this.setData({
          list:res.data
        })
      })
      .catch(res => {
        console.error('添加失败',res)
      })
    },

    detail(e) {
      console.log(e)
      console.log("audio1传值",e.currentTarget.dataset.id)
      wx.navigateTo({
        url: '/pages/audiotion6-ismy/audiotion6-ismy?id=' + e.currentTarget.dataset.id,
      })
    },

      // 搜索
 searchList: function(ev){
  console.log('输入框内容?')
  let e = ev.detail;
  this.data.searchstr = e.detail.value
  console.log(this.data.searchstr,'输入框内容')
  var searchstr = this.data.searchstr //获取输入框输入内容
  this.setData({
    searchstr: e.detail.value
  })
 },//监听输入框内容

 endsearchList(e) {
  console.log('搜索框回调函数')
  db.collection('lost_storage')

  .where({
    name:{
      $regex:'.*'+ this.data.searchstr,
      $options: 'i'
    } //匹配输入内容
  })
  .get({
    success : res =>{
      if (res.data.length == 0) {
        wx.showModal({
          title: '提示',
          content: '暂时没找到对应答案',
          showCancel: false,
          success: function (res) { }
        })
        return;
      }
      else{
        console.log('[搜索成功]',res)
        
        this.setData({
          search_result : true,
          all_result:false
         })
      }
      this.setData({
        good : res.data
       })
      //  wx.navigateTo({
      //   url: '/pages/audiotion1/audiotion1?name=' + this.data.searchstr,
      // })
     }
   })
},//搜索回调

// 取消搜索
cancelsearch() {
  this.setData({
    searchstr: ''
  })
},

//清空搜索框
activity_clear(e) {
  this.setData({
    searchstr: ''
  })
},
})

