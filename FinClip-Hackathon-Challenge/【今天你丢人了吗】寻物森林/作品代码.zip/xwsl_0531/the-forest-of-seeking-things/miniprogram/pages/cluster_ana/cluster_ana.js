// pages/cluster_ana/cluster_ana.js
const db = wx.cloud.database({
  env: 'cloud1-2g7s81h60f3fd184'
})
var people = new Array


Page({
  data: {
    r_list:[],
    target_user:[],
    people:[]
  },

  onLoad: function (options) {
    this.ranklist()
    this.forgetful()
    this.Warmh_M()
  },

  //丢失物品出现频次
  ranklist() {
    let that = this
    db.collection('try_5-10')
    .aggregate()
    .sortByCount('$name')
    .end()
    .then(res =>{
      console.log("丢失物品",res.list)
      console.log("丢失物品对应名称",res.list[0]._id)
      console.log("丢失物品对应次数",res.list[0].count)
      let pageData = res.list
      that.setData({
        r_list:pageData
      })
    })
    .catch(err => {
      console.log("错误",err)
    })
  },

  //失物主出现频次（或者可以改成活跃榜，不区分type）
  forgetful() {
    db.collection('try_5-10')
    .aggregate()
    .match({
      type:"丢失"
    })
    .sortByCount('$_openid')
    .end()
    .then(res=>{
      console.log("大头蛇",res)
      this.setData({
        target_user:res
      })
      this.Dir_matching()
    })
  },

  Dir_matching() {
    let that = this
    console.log("match",this.data.target_user.list[0]._id)
    for (var i=0; i<this.data.target_user.list.length; ++i) {
      console.log(this.data.target_user.list[i]._id)
      wx.cloud.database().collection("User_inform")
        .where({
          _openid:this.data.target_user.list[i]._id
        })
        .get()
        .then(res =>{
          console.log("获取成功",res.data[0])
          let obj = res.data[0]
          this.data.people.push(obj)
          this.setData({
            people:people
          })
          console.log("test",this.data.people)
        })
        .catch(err =>{
          console.log("获取失败",err)
        })
    }
  },

  Warmh_M() {
    db.collection("GoodMan_list")
    .aggregate()
    .sortByCount('$user')
    .end()
    .then(res => {
      console.log("聚合计数成功",res)
    })
    .catch(err => {
      console.log("计数失败",err)
    })
  }
})