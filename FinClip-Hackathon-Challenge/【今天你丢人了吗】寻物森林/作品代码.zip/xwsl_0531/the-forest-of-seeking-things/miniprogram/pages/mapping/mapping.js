// pages/mapping/mapping.js
let ID =''
let dianzan = false

Page({

  data: {
    thing:{},
    detail:[],
    like_url:"cloud://cloud-m01-t5i5m.636c-cloud-m01-t5i5m-1304238103/images/like_bef.png"
  },

  onLoad(options) {
    console.log("audio传值",options)
    ID = options.id
    this.getDetail()
    wx.cloud.database().collection("share")
    .doc(ID)
    .get()
    .then(res => {
      console.log("信息获取成功",res)
      dianzan = res.data.dianzan
      this.setData({
        detail:res.data,
        like_url: dianzan ? "cloud://cloud1-2g7s81h60f3fd184.636c-cloud1-2g7s81h60f3fd184-1306014217/like.png":"cloud://cloud1-2g7s81h60f3fd184.636c-cloud1-2g7s81h60f3fd184-1306014217/like_bef.png"
      })
    })
    .catch(err => {
      console.log("获取失败",err)
    })
  },

  getDetail() {
    wx.cloud.database().collection('share')
    .doc(ID)
    .get()
    .then(res => {
      console.log('查询成功',res)
      this.setData({
        thing:res.data
      })
      console.log(this.data.thing.pic1)
    })
    .catch(err => {
      console.error('查询失败',err)
    })
  },

  clickMe() {
    this.setData({
      like_url: dianzan ? "cloud://cloud1-2g7s81h60f3fd184.636c-cloud1-2g7s81h60f3fd184-1306014217/like_bef.png" : "cloud://cloud1-2g7s81h60f3fd184.636c-cloud1-2g7s81h60f3fd184-1306014217/like.png"
    })
    dianzan = ! dianzan
    wx.cloud.callFunction({
      name:"like",
      data:{
        id: ID,
        dianzan:dianzan
      }
    }).then(res=>{
      console.log("改变状态成功",res)
    }).catch(err=>{
      console.log("改变状态失败",err)
    })
    
    // if (dianzan) {
    //   this.setData({
    //     like_url:"cloud://cloud-m01-t5i5m.636c-cloud-m01-t5i5m-1304238103/images/like_bef.png"
    //   })
    //   dianzan = false
    // } else {
    //   this.setData({
    //     like_url:"cloud://cloud-m01-t5i5m.636c-cloud-m01-t5i5m-1304238103/images/like.png"
    //   })
    //   dianzan =  true
    // }
  },

  onShareAppMessage() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    })
  },
  
  onShareTimeline(e) {
    console.log(e)
    return {
      title: '分享至朋友圈',
      path:''
    }
  },
})