// pages/version/version.js
var num = 0

Page({
  data: {
    product:{
      name: '寻物森林',
      version_n: '1.0.9',
      release: '2021-8-25',
      descri: '新增失物驿站管理端版块,将每周话题版块改为学院动态。移除用户上传拾物信息与失物匹配功能',
      num:0,
    }
  },

  
  onLoad: function (options) {
    console.log("welcome")
  },

  Easter_egg() {
    num = num + 1
    console.log("计数",num)
    this.setData({
      num:num
    })
    if (num >5) {
      wx.navigateTo({
        url: '/pages/about/about?tap=' + "egg",
      })
    }
  }
})