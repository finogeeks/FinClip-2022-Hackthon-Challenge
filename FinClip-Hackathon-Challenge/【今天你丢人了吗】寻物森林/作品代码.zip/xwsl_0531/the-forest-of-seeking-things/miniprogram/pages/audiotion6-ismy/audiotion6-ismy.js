// pages/audiotion6/audiotion6.js
var id=''
// var codeup=false
var temp = []


Page({
  data: {
    good:{},
    ccode:[]
  },

  onLoad(options) {
    console.log("audio传值",options)
    id = options.id
    this.getDetail()
  },

  onShow() {
    
  },

  getDetail() {
    wx.cloud.database().collection('try_5-10')
    .doc(id)
    .get()
    .then(res => {
      console.log('商品详情查询成功',res)
      this.setData({
        good:res.data
      })
    })
    .catch(res => {
      console.error('商品详情查询失败',res)
    })
  },

  onShareAppMessage() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    })
  },
  
  onShareTimeline(e) {
    console.log(e)
    return {
      title: '分享至朋友圈',
      path:''
    }
  },

  tcode() {
    let that = this
    wx.showModal({
      title: '确认认领该物品吗',
      content: '认领后，您的取物信息将保存',
      success: function (res) {
        if (res.confirm) {  
          console.log('点击确认回调')
          that.setcode()
        } else {   
          console.log('点击取消回调')
        }
      }
    })
  },

  setcode() {
    let cc = ""
    for (var i=1;i<=6;i++) {
      const num = Math.floor(Math.random()*10);
      cc += num
    }
    console.log("取件码",cc)
    wx.showModal({
      title:"取件码",
      content:cc,
    })
  }
})