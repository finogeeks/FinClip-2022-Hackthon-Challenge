// timeline3/timeline3.js
Page({

  data: {
    dialogShow: false,
    showOneButtonDialog: false,
    buttons: [{text: '取消'}, {text: '确定'}],
    oneButton: [{text: '确定'}],
  },

  // 弹窗sth
  openConfirm: function () {
    this.setData({
        dialogShow: true
    })
},

tapDialogButton(e) {
    this.setData({
        dialogShow: false,
        showOneButtonDialog: false
    })
},


tapOneDialogButton(e) {
    this.setData({
        showOneButtonDialog: true
    })
},

dialog(){
  this.setData({
    dialogShow : true
  })
  console.log("dialogShow:",this.data.dialogShow)
},


  // 跳转捐物发布页
  daonate:function(){
    wx.navigateTo({
      url: '/pages/daonatemsg/daonatemsg',
    })
  },

  onLoad: function (options) {

  },

  onShareAppMessage() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    })
  },
  
  onShareTimeline(e) {
    console.log(e)
    return {
      title: '分享至朋友圈',
      path:''
    }
  },
})