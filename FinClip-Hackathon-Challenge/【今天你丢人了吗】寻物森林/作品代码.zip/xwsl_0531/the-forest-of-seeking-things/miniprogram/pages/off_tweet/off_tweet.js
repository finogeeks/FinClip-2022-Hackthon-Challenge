var src=""
var pic =""
var id = ""
const DB = wx.cloud.database({
  env: 'cloud1-2g7s81h60f3fd184'
}).collection("Tweet")

Page({
  data: {
    judge:"",
    tweet_name:"",
    tweet_url:"",
    tweet_pic:"",
    img_f1:[],
    pgf:"",
    tid:[],
    tweet_con:{}
  },

  onLoad(options) {
    console.log(options)
    id = options.id
    if (options.pg=="false") {
      DB.doc(id).get()
      .then(res=>{
        console.log("获取成功",res)
        this.setData({
          tweet_con:res.data,
          tweet_name:res.data.t_name,
          tweet_url:res.data.t_url,
          src:res.data.t_pic,
          judge:1
        })
      })
      .catch(err=>{
        console.log("获取失败",err)
      })
    }
    this.setData({
      pgf:options.pg,
    })
  },

  //上传文字封面
  f0: function(event){
    let that = this;
    var that_ = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function(res){
        console.log("选择成功",res)
        that_.setData({
          src:res.tempFilePaths[0],
          src_list:res.tempFilePaths,
          judge:res.tempFilePaths["length"]   
         })
        var src_list=res.tempFilePaths
        console.log("src_list",src_list)
        src_list.forEach((item,idx)=>{
          var fileName=Date.now()+"_"+idx;
          that.uploadImg(fileName,item)
        })
        },
    })
    that.uploadImg()
  },

  //上传图片到云开发
uploadImg(fileUrl,path){
  var that = this
  wx.cloud.uploadFile({
    cloudPath: fileUrl+'example.png',
    filePath: path,
    success: res => {
      pic=res.fileID
       console.log("上传成功",res)
       that.setData({
        img_f1:res.fileID
      })
      console.log("照片",pic)
      console.log("cloundPath",cloundPath)
      that.setData({
        pic: res.fileID
      })    
    },
    fail: console.error
  })
},

f1:function(event){
  let currentUrl = this.data.img_f1
  var dataArray = [];
  dataArray[0] = currentUrl
  wx.previewImage({
     current: dataArray[0], // 当前显示图片的http链接
     urls: dataArray, // 需要预览的图片http链接列表
    success:function(res){
      console.log("预览成功",res)
    }
  })
},

con_title(e) {
  console.log("标题",e.detail.value)
  this.setData({
    tweet_name:e.detail.value
  })
},

con_url(e) {
  console.log("链接",e.detail.value)
  this.setData({
    tweet_url:e.detail.value
  })
},

add_tweet() {
  wx.showModal({
    title:"确认发布此文章",
    success:(res)=>{
      if (res.confirm) {
        console.log("链接",this.data.tweet_url)
        console.log("标题",this.data.tweet_name)
        console.log("封面",pic)
        DB.add({
          data:{
            t_url:this.data.tweet_url,
            t_name:this.data.tweet_name,
            t_pic:this.data.img_f1,
            t_location:"subfield",
            time:new Date()
          }
        }).then(res=>{
          console.log("上传成功",res)
          wx.showToast({
            title: '发布成功',
          })
        }).catch(err=>{
          console.log("上传失败",err)
        })
      } else {
        console.log("取消发布")
      }
    }
  })
},

go_management() {
  wx.navigateTo({
    url: '/pages/tweet_manage/tweet_manage',
  })
},

delete_tweet() {
  wx.showModal({
    title:"提示",
    content:"是否删除该发布信息",
    success(res) {
      console.log(res)
      if (res.confirm) {
        DB.doc(id).remove({})
        .then(res=>{
          console.log("删除成功",res)
         wx.navigateBack({
           url:'/pages/tweet_manage/tweet_manage'
         })
        })
        .catch(err =>{
          console.log("删除失败",err)
        })
      }
    }
  })
},

go_management() {
  wx.navigateTo({
    url: '/pages/tweet_manage/tweet_manage',
  })
},

update_tweet() {
  wx.showModal({
    title:"提示",
    content:"是否删除该发布信息",
    success:(res)=> {
      console.log(res)
      if (res.confirm) {
        DB.doc(id).update({
          data:{
            t_name:this.data.tweet_name,
            t_url:this.data.tweet_url,
            t_pic:this.data.tweet_pic
          }
        }).then(res=>{
          console.log('更新成功',res)
          wx.navigateBack({
            url:"/pages/tweet_manage/tweet_manage"
          })
        }).catch(err=>{
          console.log('更新失败',err)
        })
      }
    }
  })
},

})