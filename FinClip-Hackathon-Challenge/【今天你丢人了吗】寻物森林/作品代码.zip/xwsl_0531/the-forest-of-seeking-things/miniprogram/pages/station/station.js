// pages/station/station.js
// var content =''
const DB = wx.cloud.database({
  env: 'cloud1-2g7s81h60f3fd184'
})

Page({
  data: {
    getcategory:'',
    list:{},
    good:{},
    show:false,//控制下拉列表的显示隐藏，false隐藏、true显示
    selectData:['时间','8:00am','10:00am','12:00am','2:00pm','4:00pm','6:00pm','8:00pm','10:00pm'],//下拉列表的数据
    index:0,//选择的下拉列表下标
    content_css:[],
    search_result:false,
    all_result:true,
    id : "",
    page_state:true
    },

//点击预览图片
// f1:function(event){
//   let currentUrl = this.data.good.pic1;
//   var dataArray = [];
//   dataArray[0] = currentUrl
//   wx.previewImage({
//      current: dataArray[0], // 当前显示图片的http链接
//      urls: dataArray, // 需要预览的图片http链接列表
//     success:function(res){
//       console.log("1111",res)
//     }
//   })
// },


    //删除数据
delete_data(e) {
  var id = e.currentTarget.dataset.id
  wx.showModal({
    title:"提示",
    content:"是否下架该失物信息",
    success(res) {
      console.log(res)
      if (res.confirm) {
        wx.cloud.database().collection('lost_storage')
        .doc(id).remove({})
        .then(res=>{
          console.log("删除成功",res)
         wx.navigateBack({
           url:'/pages/station/station?id=' + id
         })
        })
        .catch(err =>{
          console.log("删除失败",err)
        })
      }
    }
  })
},

  // 跳转修改
  modify_data(e) {
      console.log('跳转至修改',e)
      console.log('即将传值：',e.currentTarget.dataset.id)
      wx.navigateTo({
        url: '/pages/modify_storage/modify_storage?id=' + e.currentTarget.dataset.id,
      })
    },


// 发布“拾物待领”
add(e){
  console.log("发布拾物待领")
  wx.navigateTo({
    url: '/pages/storage/storage?type=' + "false"
  })
},

back(e){
  this.setData({
    all_result:true,
    search_result:false
  })
  this.activity_clear(e)
},


    onLoad(options) {
      console.log(options)
      var content = options.store
      var category = options.title
      console.log("分类选择传值",options.title)
      console.log("物品",options.store)
      this.getlist(content)
      if(category == undefined){
        console.log("000")
      }
      else{
        console.log("category:",category)
        // this.getcategory(category)
        this.getcategory(category)
      }
    },

    onShow() {
      this.getlist()
    },

    // 类别搜索
    getcategory(e){
      this.setData({
        searchstr:e
      })
      // this.searchList(this.data.getcategory)
      var searchstr = this.data.searchstr //获取输入框输入内容
      this.endsearchList(searchstr)
    },

    getlist(e) {
     console.log('位置',e)
      DB.collection('lost_storage')
      .get()
      .then(res => {
        console.log('添加成功',res)
        this.setData({
          list:res.data
        })
      })
      .catch(res => {
        console.error('添加失败',res)
      })
    },

    detail(e) {
      console.log(e)
      console.log("audio1传值",e.currentTarget.dataset.id)
      // wx.navigateTo({
      //   url: '/pages/audiotion6-ismy/audiotion6-ismy?id=' + e.currentTarget.dataset.id,
      // })
    },

      // 搜索
 searchList: function(ev){
  console.log('输入框内容?')
  let e = ev.detail;
  this.data.searchstr = e.detail.value
  console.log(this.data.searchstr,'输入框内容')
  var searchstr = this.data.searchstr //获取输入框输入内容
  this.setData({
    searchstr: e.detail.value
  })
 },//监听输入框内容

 endsearchList(e) {
  
  console.log('搜索框回调函数')
  const DB = wx.cloud.database();
    const _ = DB.command
    DB.collection('lost_storage').where(_.or([{
        name: DB.RegExp({
          regexp: '.*' + this.data.searchstr,
          options: 'i',
        })
      },
      {
        lost_number: DB.RegExp({
          regexp: '.*' + this.data.searchstr,
          options: 'i',
        })
      },
      {
        category_lab_msg: DB.RegExp({
          regexp: '.*' + this.data.searchstr,
          options: 'i',
        })
      }
    ]))
  .get({
    success : res =>{
      console.log(res)
      if (res.data.length == 0) {
        wx.showModal({
          title: '提示',
          content: '暂时没找到对应答案',
          showCancel: false,
          success: function (res) { }
        })
        return;
      }
      else{
        console.log('[搜索成功]',res)
        
        this.setData({
          search_result : true,
          all_result:false
         })
      }
      this.setData({
        good : res.data
       })
      //  wx.navigateTo({
      //   url: '/pages/search result/search result?name=' + this.data.searchstr,
      // })
     }
   })
},//搜索回调

// 取消搜索
cancelsearch() {
  this.setData({
    searchstr: ''
  })
},

//清空搜索框
activity_clear(e) {
  this.setData({
    searchstr: ''
  })
},

godetail(e) {
  console.log("物品id",e)
  var ps = this.data.page_state
  wx.navigateTo({
    url: '/pages/storage/storage?id=' + e.currentTarget.dataset.id + "&type=" + "true" + "&ps=" + ps,
  })
},

change_state() {
  this.setData({
    page_state:false,
  })
},

change_state2() {
  this.setData({
    page_state:true,
  })
}

})

