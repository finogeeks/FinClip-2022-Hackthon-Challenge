// pages/chat/chat.js
var plugin = requirePlugin("chatbot");
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },



  openWebview: function(e) {
    let url = e.detail.weburl
    wx.navigateTo({
        url:'/pages/chat_index/chat_index'
    })
},


// getQueryCallback回调 返回query与结果
getQueryCallback: function (e) {
  var listData = this.data.listData
  listData.push(e.detail)
   console.log("---",res)
  if (listData.length === 10) {
    wx.navigateTo({
      url: '../../pages/chat_index/chat_index',
    })
  }
 
},
// goBackHome回调 返回上一级页面
goBackHome: function () {
  wx.navigateBack({
    delta: 1
  })
},




// getQueryCallback回调 返回query与结果
// getQueryCallback: function (e) {
  // var listData = this.data.listData
  // listData.push(e.detail)
//  const url = 'https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.getStorage.html'; // 跳转的外链
//       const navtitle = 'itclanCoder'; // 这个标题是你自己可以设置的

//   if (listData.length === 10) {
//     wx.navigateTo({
     
    
//         // 跳转到webview页面
//         url: `/pages/webview/webview?url=${url}&nav=${navtitle}`,
//     })
//   }
// var listData = this.data.listData
//     listData.push(e.detail)
//     if (listData.length === 10) {
//       wx.navigateTo({
//         url: '../../pages/chat_index/chat_index',
//       })
//     }

// },
// // goBackHome回调 返回上一级页面
// goBackHome: function () {
//   wx.navigateBack({
//     delta: 1
//   })
// },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // var appid = "bYbdPwlqVyjk8D49BkjxtfJZnJuHYe"
    // plugin.init({
    //   appid: appid,
      
    //   success: () => {},
    //   fail: error => {},
    //   guideList: ["中午吃啥呢"],
    //   textToSpeech: 1,
    //   welcome: "请问有什么需要帮助？",
    //   welcomeImage: 'http://inews.gtimg.com/newsapp_bt/0/10701537095/1000',
    //   background: "rgba(247,251,252,1)",
    //   guideCardHeight: 40,
    //   operateCardHeight: 90,
    //   history: true,
    //   navHeight: 0,
    //   robotHeader: 'https://res.wx.qq.com/mmspraiweb_node/dist/static/miniprogrampageImages/talk/leftHeader.png',
    //   userHeader: 'https://res.wx.qq.com/mmspraiweb_node/dist/static/miniprogrampageImages/talk/rightHeader.png',
    //   userName: '',
    //   anonymous: false,
    //   hideMovableButton: false
    // });



    wx.getStorage({
      key:'p_openid',

      success(res){
        console.log(res.data)
        console.log("yyy")
        var openid = res.data
        wx.getStorage({
          key:"user",
          success(res){
            console.log(openid,res.data.avatarUrl,res.data.nickName)
            var avatarUrl=res.data.avatarUrl
            var nickName = res.data.nickName
            // var appid_chat = "bYbdPwlqVyjk8D49BkjxtfJZnJuHYe"
            plugin.init({
              appid: "bYbdPwlqVyjk8D49BkjxtfJZnJuHYe",
              openid: openid, //用户的openid，必填项，可通过wx.login()获取code，然后通过后台接口获取openid
              success: () => {
                console.log("nn")
              },
              fail: error => {
                console.log("mm")
              },
              guideList:["中午吃啥呢"],
              // guideList: ["今天丢了东西好伤心"]["给我推荐首歌吧"]["中午吃啥呢"]["今天广州的天气如何"]["我爸爸的姐姐的女儿我叫啥"]["最新疫情通报"]["重返大学"]["有志者事竟成用英语怎么说"],
              textToSpeech: 1,
              welcome: "请问有什么需要帮助？",
              welcomeImage: 'http://inews.gtimg.com/newsapp_bt/0/10701537095/1000',
              background: "rgba(247,251,252,1)",
              guideCardHeight: 40,
              operateCardHeight: 90,
              history: true,
              navHeight: 0,
              robotHeader: 'https://636c-cloud-m01-t5i5m-1304238103.tcb.qcloud.la/images/map%E9%A1%B5-%E5%85%94.png?sign=202ae31d922ae1e389fcb68e947adbc8&t=1621729695',
              userHeader: avatarUrl,
              userName: nickName,
              anonymous: false,
              hideMovableButton: false
            });
          plugin.send({
          query: "",
          success: res => {
            console.log(res);
          },
          fail: error => {}
        });


          },
          fail: error => {
            console.log("错误")
          }
        
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})