var pick_res = []
var mr_res = []

Page({
  data: {
    list:[],
    ugc:[],
    pick_con:[],
    mr:[],
    target_good:[]
  },

  onLoad: function (options) {
    this.getOpenid()
    this.getpickn()
    
  },

 //获取匹配值相应数据，并进行排序处理
 getres() {
  wx.cloud.database().collection("Related_items")
    .aggregate()
    .sort({
      relevancy:-1
    })
    .end()
    .then(res =>{
      console.log("数据清洗完成",res.list)
      this.setData({
        target_good:res.list
      })
      wx.hideLoading()
    })
    .catch(err =>{
      console.log(err)
      wx.hideLoading()
    })
 },

 // 删除openid对应的Related_items数据
  delete_oc() {
    console.log("listopenid",this.data.list)
    wx.cloud.callFunction({
      name:'deletem',
      data: {
        oi:this.data.list
      }
    }).then(res=>{
      console.log('调用成功',res)
      this.getdata()
    }).catch(err=>{
      console.log('调用失败',err)
    })
  },

  // 获取Openid
    getOpenid() {
      wx.showLoading({
        title: '智能匹配中~',
      })
      wx.cloud.callFunction({
        name:"getopenid"
      }).then(res=>{
        console.log("获取openid成功",res.result.event.userInfo.openId)
        this.setData({
          list:res.result.event.userInfo.openId
        })
        this.delete_oc()
      }).catch(err=>{
        console.log("获取失败",err)
      })
    },

//获取openid对应try_5-10数据
    getdata() {
      wx.cloud.database().collection('try_5-10')
      .where({
        _openid:this.data.list,
        type:"丢失",
        state:"寻找中"
      })
      .get()
      .then(res => {
        console.log('个人发布内容查询成功',res)
        this.setData({
          ugc:res.data
        })
        this.matchvalue()
      })
      .catch(res => {
        console.error('查询失败',res)
      })
    },

  //获取type:捡到了,对应try_5-10数据
    getpickn() {
      wx.cloud.database().collection('try_5-10')
      .where({
        type:"捡到",
      })
      .get()
      .then(res => {
        console.log('拾获内容查询成功',res)
        this.setData({
          pick_con:res.data
        })
        // for (let i = 0; i < res.data.length; i++) {
        //   let res = res.data[i]
        //   let r = res.name + res.moren_lab1 + res.moren_lab2 + res.category_lab_msg.name + res.category_lab_msg.title + res.lost_placename + res.losttime
        //   pick_res.push(r)
        // }
      })
      .catch(res => {
        console.error('查询失败',res)
      })
    },

  //文本对比输出相似度
    getSimilarity() {
      let str1 = "12301924192470"
      let str2 = "12301924192"
      let sameNum = 0
      //寻找相同字符
      for (let i = 0; i < str1.length; i++) {
          for(let j =0; j< str2.length; j++){
              if(str1[i]===str2[j]){
                  sameNum ++ 
                  break
              }
          }
      }
      let length = str1.length > str2.length ? str1.length : str2.length
      let result =  (sameNum/length) * 100 || 0
      console.log("相似值",result)
      let mr = Math.round(result*100)/100
      console.log("相似值前4为",mr)
      this.setData({
        mr:mr
      })
    },

  //循环匹配
  matchvalue() {
    var c1 = this.data.ugc
    var c2 = this.data.pick_con
    for (let i = 0; i < c1.length; i++) {
      console.log("用户丢失数据",i,c1[i])
      let res = c1[i]
      console.log("丢失数据文本合集:",res.name + res.moren_lab1 + res.moren_lab2 + res.category_lab_msg.name + res.category_lab_msg.title + res.lost_placename + res.losttime)
      let c11 = res.name + res.moren_lab1 + res.moren_lab2 + res.category_lab_msg.name + res.category_lab_msg.title + res.lost_placename + res.losttime
        for(let a = 0; a < c2.length; a++) {
          let res2 = c2[a]
          let c22 = res2.name + res2.moren_lab1 + res2.moren_lab2  + res2.lost_placename + res2.losttime
          let str1 = c11
          let str2 = c22
          let sameNum = 0
          for (let i = 0; i < str1.length; i++) {
            for(let j =0; j< str2.length; j++){
                if(str1[i]===str2[j]){
                    sameNum ++ 
                    break
                }
            }
        }
        let length = str1.length > str2.length ? str1.length : str2.length
        let result =  (sameNum/length) * 100 || 0
        console.log("相似值",result)
        let mr = Math.round(result*100)/100
        console.log("相似值前4为",mr)
        mr_res.push(mr)
          this.setData({
            mr:mr
          })
          wx.cloud.database().collection('Related_items')
          .add({
            data:{
              relevancy:mr,
              try_id:res2._id,
              name:res2.name,
              moren_lab1:res2.moren_lab1,
              moren_lab2:res2.moren_lab2,
              lost_placename:res2.lost_placename,
              losttime:res2.losttime,
              pic:res2.pic1
            },
            success(res){
              console.log("上传成功",res)
            },
            fail(err){
              console.log("上传失败",err)
            },
          })
        }
    }
    this.getres()
  },

// 先获取用户发布过的所有信息A与所有“拾获”的信息B
// 首选循环A、B，分别生成文本a和b
// 匹配a、b文本相关度后，将相关度与该物品的信息一起上传至一个新数据集
// 最后通过openid获取数据集中对应的数据
// 每次进入页面先清空该用户openid对应数据集的所有数据，再后执行上面的方法

 //点击跳转详情
  getdetail(e) {
    console.log(e)
    console.log("audio1传值",e.currentTarget.dataset.id)
    wx.navigateTo({
      url: '/pages/audiotion6-ismy/audiotion6-ismy?id=' + e.currentTarget.dataset.id,
    })
  }
})