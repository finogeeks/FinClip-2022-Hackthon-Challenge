Page({
  data: {
    tabs: [],
    activeTab: 0,
    first:true,
    target_user:[],
    target_ava:[]
  },

  onLoad() {
    const titles = ['好人榜']
    const tabs = titles.map(item => ({title: item}))
    this.setData({tabs})
    this.get_gml()
    this.get_gava()
  },

  onTabCLick(e) {
    const index = e.detail.index
    this.setData({
      activeTab: index, 
    })
    console.log("index:",index,this.data.activeTab)
  },

  onChange(e) {
    const index = e.detail.index
    this.setData({activeTab: index})
    console.log("-index:",index)
  },

  onShareAppMessage() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    })
  },
  
  onShareTimeline(e) {
    console.log(e)
    return {
      title: '分享至朋友圈',
      path:''
    }
  },

  get_gml() {
    wx.cloud.database().collection('GoodMan_list')
    .aggregate()
    .sort({
      count:-1
    })
    .sortByCount('$nickName')
    .end()
    .then(res=>{
      console.log("gml",res)
      this.setData({
        target_user:res
      })
      console.log("gdata",this.data.target_user)
    })
  },

  get_gava() {
    wx.cloud.database().collection('GoodMan_list')
    .aggregate()
    .sort({
      count:-1
    })
    .sortByCount('$avatarUrl')
    .end()
    .then(res=>{
      console.log("gava",res)
      this.setData({
        target_ava:res
      })
      console.log("avad",this.data.target_ava)
    })
  },
})
