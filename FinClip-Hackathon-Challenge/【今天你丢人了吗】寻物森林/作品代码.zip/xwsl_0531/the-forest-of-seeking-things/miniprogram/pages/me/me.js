// logs.js
// const util = require('../../utils/util.js')

Page({
  data: {
    logs: [],
    code:"",
    weather_icon:"",
    weather_container:"",
    group_rain_stormy:"",
    group_sun_cloud:"",
    tmp:"",
    cond_txt:"",
    userInfo: {},
    hasUserInfo: false,
    canIUseGetUserProfile: false,
    showLoginIN:false,
    account:null,
    password:null
  },

  enter_ur() {
    console.log("openid传值",this.data.list)
    wx.navigateTo({
      url: '/pages/psonal_rec/psonal_rec?openid=' + this.data.list,
    })
  },

  // 获取Openid
  getOpenid() {
    wx.cloud.callFunction({
      name:"getopenid"
    }).then(res=>{
      console.log("获取openid成功",res.result.event.userInfo.openId)
      this.setData({
        list:res.result.event.userInfo.openId
      })
    }).catch(err=>{
      console.log("获取失败",err)
    })
  },


  onLoad() {
    var that = this
    var key = "9ef0cb60a0814693ae610063cfff020a"
    var longitude = '113.679287'
    var latitude = '23.632575'
    var url ='https://free-api.heweather.com/s6/weather?key='+key+'&location=' + longitude + ','+latitude
    var user = wx.getStorageSync('user');

    if(user) {
      console.log('用户信息已授权')
      that.setData({
        hasUserInfo:true,
        userInfo: user,
      })
      console.log("用户信息",that.data.userInfo)
    }

    wx.request({
      url: url,
      // data:struct,
      success: function(res) {
        console.log(res);
        let cond_txt = res.data.HeWeather6[0].now.cond_txt;//天气
        var cond_code = res.data.HeWeather6[0].now.cond_code;//天气对应编码
        var tmp = res.data.HeWeather6[0].now.tmp //温度
        if (cond_code==101 || cond_code==102 || cond_code==104 || cond_code==154)
        {
          that.setData({
            weather_icon : "cloudy",
            weather_container : "container_cloudy",
            cond_txt: cond_txt,
            tmp: tmp,
          }) 
          console.log("cloudy温度",tmp);
          console.log("cloudy天气",cond_txt);  
        }

        
        else if (cond_code==100 || cond_code==150)
        {
          that.setData({
            weather_icon : "sunny",
            weather_container : "container_sunny",
            cond_txt: cond_txt,
            tmp: tmp,
          })   
        console.log("sunny温度",tmp);
        console.log("sunny天气",cond_txt);
        }
        
        else if (cond_code==300 || cond_code==301 || cond_code <=312 && cond_code >=305 || cond_code <=351 && cond_code >=314)
        {
          that.setData({
            weather_icon : "rainy",
            weather_container : "container_rainy",
            cond_txt: cond_txt,
            tmp: tmp,
          })   
          console.log("rainy温度",tmp);
        console.log("rainy天气",cond_txt);
        }
      

        else if (cond_code==302 || cond_code==303 ||cond_code==304)
        {
          that.setData({
            weather_icon : "rain_stormy",
            weather_container : "container_rain_stormy",
            group_rain_stormy:"stormy_rain",
            cond_txt: cond_txt,
            tmp: tmp,
          }) 
          console.log("rain_stormy温度",tmp);
        console.log("rain_stormy天气",cond_txt);  
        }

        else if (cond_code==103 || cond_code==153)
        {
          that.setData({
            weather_icon : "sun_cloud",
            weather_container : "container_sun_cloud",
            group_sun_cloud:"1",
            cond_txt: cond_txt,
            tmp: tmp,
          })   
          console.log("sun_cloud温度",tmp);
        console.log("sun_cloud天气",cond_txt);
        }


        
        // var cond_code_d = res.data.HeWeather6[0].now.cond_code;
        // var tmp = res.data.HeWeather6[0].now.tmp;//当前温度
        // var hum = res.data.HeWeather6[0].now.hum;//空气质量
        // var tmp_min = res.data.HeWeather6[0].daily_forecast[0].tmp_min;//最高温度
        // var tmp_max = res.data.HeWeather6[0].daily_forecast[0].tmp_max;//最低温度
        // var daily_forecast = res.data.HeWeather6[0].daily_forecast;//连续三天的天气情况数组
      },
      fail: function(res) {
        console("api调用失败")
      },
      complete: function(res) {},
    })
    this.getOpenid()
  },
  access_code() {
    // wx.navigateTo({
    //   url: "/pages/homepage/homepage",
    // }) 
  },

  tmp_d() {
    console.log("温度传值",this.data.tmp)
  },

  service() {
    var that = this
  },

  feedback() {
    var that = this
  },

  get_Profile() {
    wx.getUserProfile({
      lang:'zh_CN',
      desc: '用于完善会员资料', 
      success: (res) => {
        console.log("用户信息",res)
        this.Upload_userinfo(res)
        if (!this.hasUserInfo && res.userInfo) {
          wx.showToast({
            title: '授权成功',
          })
          wx.setStorageSync('user',res.userInfo)
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      }
    })
  },

  //存储用户授权的信息
  Upload_userinfo(res) {
    wx.cloud.database().collection("User_inform")
        .add({
          data:{
            avatarUrl:res.userInfo.avatarUrl,
            nickName:res.userInfo.nickName,
            city:res.userInfo.city,
            country:res.userInfo.country,
            gender:res.userInfo.gender,
            province:res.userInfo.province
          },
          success(res) {
            console.log("上传成功",res)
          },
          fail(err) {
            console.log("上传失败",err)
          }
        })
  },

  getUserInfo(e) {
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },

  Skip_helf() {
    wx.navigateTo({
      url: '/pages/usinghelf/usinghelf',
    })
  },

  skip_version() {
    wx.navigateTo({
      url: '/pages/version/version',
    })
  },

  skip_about() {
    wx.navigateTo({
      url: '/pages/about/about',
    })
  },

  chat(){
    wx.navigateTo({
      url: '/pages/chat/chat',
    })
  },

  LoginIn() {
    this.setData({
      showLoginIN:true
    })
  },

  onCancel() {
    this.setData({
      showLoginIN:false
    })
  },

  get_account(e) {
    console.log("打印账号",e.detail.value)
    this.setData({
      account:e.detail.value
    })
  },

  get_password(e) {
    console.log("打印密码",e.detail.value)
    this.setData({
      password:e.detail.value
    })
  },

  onConfirm(e) {
    var that = this
    if (that.data.account.length==0 || that.data.password.length==0) {
      wx.showToast({
        icon:"none",
        title: '账号或密码不能为空',
        duration:2000,
      })
    } else {
      if (that.data.account=="失物驿站" & that.data.password=="@swyz0527") {
        wx.showToast({
          title: '登入成功',
          duration:1000,
          success() {
            setTimeout(function() {
              wx.redirectTo({
                url: '/pages/management/management?nickName=' + that.data.userInfo.nickName +"&avatarUrl=" + that.data.userInfo.avatarUrl,
              })
            },100)
          }
        })
      } else {
        wx.showToast({
          title: '账号或密码错误',
        })
      }
    }
  },
})



