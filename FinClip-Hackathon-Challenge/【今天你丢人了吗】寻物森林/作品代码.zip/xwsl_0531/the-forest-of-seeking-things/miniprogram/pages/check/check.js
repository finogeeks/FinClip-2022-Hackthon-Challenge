var app = getApp()
var db = wx.cloud.database()
var _ = db.command

Page({
  data: {
    navbar: ['待审核', '审核记录'],
    currentTab: 0,
    good1:{},
    good2:{}
  },

  onLoad() {
    this.getPending()
    this.getCompleted()
  },

  onShow() {
    this.getPending()
    this.getCompleted()
  },

  navbarTap: function(e){
    this.setData({
      currentTab: e.currentTarget.dataset.idx
    })
  },

  getPending() {
    console.log('openid',this.data.pers_id)
    db.collection('try_5-10')
    .where({
      audit:false
    })
    .get()
    .then(res => {
      console.log('待审核信息获取成功',res)
      this.setData({
        good1:res.data
      })
    })
    .catch(res => {
      console.error('获取失败',res)
    })
  },

  getCompleted() {
    console.log('openid',this.data.pers_id)
    db.collection('try_5-10')
    .where({
      audit:true
    })
    .get()
    .then(res => {
      console.log('待审核信息获取成功',res)
      this.setData({
        good2:res.data
      })
    })
    .catch(res => {
      console.error('获取失败',res)
    })
  },

  goDetail(e) {
    console.log('跳转至修改',e)
    wx.navigateTo({
      url: '/pages/audit/audit?id=' + e.currentTarget.dataset.id,
    })
  },
})
