// pages/geo_try/geo_try.js
// var amapFile = require('../../libs/amap-wx.js');  //引入高德js
// var config = require('../../libs/config.js');      //引用我们的配置文件
Page({
  data: {
    the_location: [],
    markers:[
      // 1教
      {
        id: 0,
        longitude:113.677413,
        latitude:23.631727,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "1号教学楼",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 2教
      {
        id: 1,
        longitude:113.676890,
        latitude:23.631160,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "2号教学楼",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 3教
      {
        id: 2,
        longitude:113.677103,
        latitude:23.630880,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "3号教学楼",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 4教
      {
        id: 3,
        longitude:113.677460,
        latitude:23.630490,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "4号教学楼",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 5教
      {
        id: 4,
        longitude:113.677830,
        latitude:23.633830,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "5号教学楼",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 6教
      {
        id: 5,
        longitude:113.678230,
        latitude:23.633430,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "6号教学楼",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 7教
      {
        id: 6,
        longitude:113.678600,
        latitude:23.633330,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "7号教学楼",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 8教
      {
        id: 7,
        longitude:113.679578,
        latitude:23.634139,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "8号教学楼",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 9教
      {
        id: 8,
        longitude:113.679908,
        latitude:23.634003,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "9号教学楼",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 10教
      {
        id: 9,
        longitude:113.679740,
        latitude:23.633441,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "10号教学楼",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 11教
      {
        id: 10,
        longitude:113.679750,
        latitude:23.633101,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "11号教学楼",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 1实
      {
        id: 11,
        longitude:113.678226,
        latitude:23.631080,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "1号实验楼",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 2实
      {
        id: 12,
        longitude:113.678226,
        latitude:23.630880,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "2号实验楼",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 3实
      {
        id: 13,
        longitude:113.678460,
        latitude:23.630480,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "3号实验楼",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 4实
      {
        id: 14,
        longitude:113.679750,
        latitude:23.632701,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "4号实验楼",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 中饭
      {
        id: 15,
        longitude:113.678954,
        latitude:23.634688,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "中区饭堂",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 车站
      {
        id: 16,
        longitude:113.676954,
        latitude:23.634688,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "车站",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 音乐楼
      {
        id: 17,
        longitude:113.678760,
        latitude:23.635400,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E4%BD%8D%E7%BD%AE.png?sign=33fabefd40a19d94dbd6a2c690b1c3db&t=1627735492", 
        width:44,
        height:44,
        callout:{
          content: "音乐楼",
          padding:4,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#CFE4B6',
          color:'#006B61',
          fontSize:'15',
        }
      },
      // 失物驿站
      {
        id: 18,
        longitude:113.679750,
        latitude:23.630880,
        // alpha:0,
        iconPath:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/img_5.26%E6%94%B9icon/%E5%A4%B1%E7%89%A9%E9%A9%BF%E7%AB%99.png?sign=e910a1281c131f697728e57506b40789&t=1627827415", 
        width:160,
        height:104,
        callout:{
          content: "失物驿站",
          padding:6,
          display:'ALWAYS',
          textAlign:'center',
          borderRadius:'15',
          bgColor:'#FFFF81',
          color:'#006B61',
          fontSize:'15',
        }
      },
    ]
  },
  
// 页面跳转
  library(e){
    var markid = e.detail.markerId
    var that = this
    if (e.detail.markerId == 18){
      wx.navigateTo({
        url: '/pages/audiotion1/audiotion1'
      })
    }
    // console.log('获取data值',that.data.markers[markid].callout.content)
    // console.log(e)
    // console.log(e.detail.markerId)
    // console.log(e.currentTarget.dataset.content)
    // wx.navigateTo({
    //   url: '/pages/audiotion1/audiotion1?store='+that.data.markers[markid].callout.content,
    // })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    var _self = this;
    console.log("markers",this.data.markers)
    wx.request({
      url: 'https://restapi.amap.com/v3/geocode/geo?parameters',
      header: { 
        'Content-Type': 'application/json'
    },
      data: {
        key: "cddee357dd2e2bb7bf9df9bc69652238",
        address: "广东省广州市从化区温泉镇中山大学南方学院图书馆", 
        
      },
      success: function (res) {
        var the_location = res.data.geocodes[0].location.split(',')
        console.log("data",res.data)
        console.log("学校经纬度",res.data.geocodes[0].location)
        _self.setData({
          the_location: res.data.geocodes[0].location.split(','),
          
        })
        console.log(the_location[0])
        
      },
      fail: function (res) {
        console.log ('获取地理位置失败')
      }
    })
    // _self.markers_location("广东省广州市从化区温泉镇中山大学南方学院中区饭堂")
  },

  

})