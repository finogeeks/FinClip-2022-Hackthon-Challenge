// pages/mom_beauty/mom_beauty.js
var id=''
var userinu=''

const DB = wx.cloud.database({
  env: 'cloud1-2g7s81h60f3fd184'
}).collection("share")

Page({
  data: {
    userInfo: {},
    user_comment:{},
    hasUserInfo: false,
    gracious:[],
    userinu :[],
    status:false,
    show: false,
    duration: 300,
    position: 'right',
    round: true,
    overlay: true,
    customStyle: '',
    overlayStyle: '',
    good:{
      pic:"https://636c-cloud1-2g7s81h60f3fd184-1306014217.tcb.qcloud.la/%E5%A5%BD%E8%BF%90%E6%80%BB%E7%95%99%E7%BB%99%E5%8A%AA%E5%8A%9B%E7%9A%84%E4%BA%BA.jpg?sign=5aeee2549d37c348fc52dd036f233e85&t=1622132671",
      btit:"# 网新专业学什么",
      title:"网新同学天天敲代码？他们到底在干什么"
    },
    topic:[]
  },

  daonate: function(e){
    wx.navigateTo({
      url: '/pages/goodmsg/goodmsg',
    })
  },

  onLoad: function (options) {
    // this.getData()
    this.hidup()
    console.log("话题数据",options.id)
    id = options.id
    this.getDetail_topic()
    this.getcomment()
    this.gettopic()

    var user = wx.getStorageSync('user');
    if(user) {
      console.log('用户信息已授权')
      this.setData({
        hasUserInfo:true,
        userInfo: user,
      })
    }
  },

  //拉起弹窗
 send_pop() {
  console.log("拉起弹窗")
   const position = "bottom"
   let customStyle = ''
   let duration = this.data.duration
   switch(position) {
     case 'top':
     case 'bottom': 
       customStyle = 'height:40%;'
       break
     case 'right':
       break
   }
   this.setData({
     position,
     show: true,
     customStyle,
     duration
   })
 },

 getData() {
  wx.showLoading({
    title: '加载中',
  })
  let len = this.data.gracious.length
  console.log("当前list长度",len)
  wx.cloud.callFunction({
    name:'getdeed',
    data: {
      len:len,
      pageNum:40,
    }
  }).then(res=>{
    wx.hideLoading()
    console.log('调用成功',res.result.data)
    let datalist = res.result.data
    if (datalist.length <=0) {
      wx.showToast({
        icon:'none',
        title: '没有更多数据了',
      })
    }
    this.setData({
      gracious: this.data.gracious.concat(datalist)
    })
    console.log(this.data.gracious)
  }).catch(err=>{
    wx.hideLoading()
    console.log('调用失败',err)
  })
 },

//  mapping(e) {
//    console.log("详情id",e.currentTarget.dataset.id)
//    wx.navigateTo({
//      url: '/pages/mapping/mapping?id=' + e.currentTarget.dataset.id,
//    })
//  },

 //拉起弹窗
 send_pop() {
  console.log("拉起弹窗")
   const position = "bottom"
   let customStyle = ''
   let duration = this.data.duration
   switch(position) {
     case 'top':
     case 'bottom': 
       customStyle = 'height: 40%;'
       break
     case 'right':
       break
   }
   this.setData({
     position,
     show: true,
     customStyle,
     duration
   })
 },

 remark() {
   wx.cloud.database().collection("comment")
   add({
     data:{

     }
   })
 },

 getDetail_topic() {
  wx.cloud.database().collection('xwsl_topic')
  .doc(id)
  .get()
  .then(res => {
    console.log('物品详情查询成功',res)
    this.setData({
      good:res.data
    })
  })
  .catch(res => {
    console.error('物品详情查询失败',res)
  })
},

commc(e) {
  console.log("打印输入内容",e.detail.value)
  userinu = e.detail.value
  this.setData({
    userinu:userinu
  })
},

upcomment() {
  console.log("上传评论",this.data.userinu)
  console.log("头像",this.data.userInfo.avatarUrl)
  wx.cloud.database().collection("comment")
  .add({
    data:{
      user_c:this.data.userinu,
      avatarUrl:this.data.userInfo.avatarUrl,
      nickName:this.data.userInfo.nickName,
      type:id
    }
  })
  .then(res=>{
    console.log(res)
    wx.showToast({
      title: '发布成功',
      duration:2000,
    })
    this.setData({show: false})
  })
  .catch(err=>{
    console.log(err)
  })
},

noauth() {
  wx.getUserProfile({
    lang:'zh_CN',
    desc: '用于完善会员资料', 
    success: (res) => {
      console.log("用户信息",res)
      if (!this.hasUserInfo && res.userInfo) {
        wx.showToast({
          title: '授权成功',
        })
        this.upcomment()
        wx.setStorageSync('user',res.userInfo)
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    }
  })
},

get_Profile() {
  wx.getUserProfile({
    lang:'zh_CN',
    desc: '用于完善会员资料', 
    success: (res) => {
      console.log("用户信息",res)
      if (!this.hasUserInfo && res.userInfo) {
        wx.showToast({
          title: '授权成功',
        })
        wx.setStorageSync('user',res.userInfo)
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    }
  })
},

getcomment() {
  wx.cloud.database().collection("comment")
  .where({
    type:id
  })
  .get()
  .then(res=>{
    console.log("获取成功",res)
    this.setData({
      user_comment:res.data
    })
  })
  .catch(err =>{
    console.log("获取失败",err)
  })
},

hidup() {
  wx.cloud.database().collection("functiont")
  .get()
  .then(res=>{
    console.log("getit",res.data[0].open)
    this.setData({
      status:res.data[0].open
    })
  })
  .catch(err=>{
    console.log("lostit",err)
  })
},

gettopic() {
  wx.cloud.database().collection("topicow")
  .get()
  .then(res => {
    console.log("topic获取成功",res.data[0])
    this.setData({
      topic:res.data[0]
    })
  })
  .catch(err => {
    console.log("获取失败",err)
  })
}
})