// pages/tweet_manage/tweet_manage.js
const DB = wx.cloud.database({
  env: 'cloud1-2g7s81h60f3fd184'
}).collection("Tweet")

Page({
  data: {
    tweet_list:{}
  },

  onLoad: function (options) {
    this.get_tweet()
  },

  onShow() {
    this.get_tweet()
  },

  get_tweet() {
    DB.where({
      t_location:"subfield"
    })
    .get()
    .then(res=>{
      console.log("获取成功",res)
      this.setData({
        tweet_list:res.data
      })
    })
    .catch(err=>{
      console.log("获取失败",err)
    })
  },

  modify_d(e) {
    console.log("id",e.currentTarget.dataset.id)
    wx.navigateTo({
      url: '/pages/off_tweet/off_tweet?pg=' + false + "&id=" + e.currentTarget.dataset.id,
    })
  },
})