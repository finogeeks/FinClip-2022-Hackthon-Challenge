// pages/storage/storage.js
var pic =""
var app = getApp()
var sid = ""

const DB = wx.cloud.database().collection("lost_storage")

var lost_name=""
var category_lab_msg = ""
var lost_number = ""
var get_time = ""
var get_place = ""
var other =""
var link_man = ""
var link_phone = ""
var src=false

Page({
  data: {
    img_f1:[],
    lost_name:"物品名称",
    category_lab_msg : "失物分类",
    lost_number:"物品编号",
    get_time:"拾遗时间",
    get_place:"拾遗地点",
    get_cln:"",
    get_clp:"",
    other:"其他描述",
    pic_src:"",
    date:new Date(),
    judge:"",
    open_id:[],
    datab:[],
    type:"",
    pic:"",
    src:"",
    show_expic:true,
    show_newpic:false,
    s_record:false,
    account:null,
    password:null,
    page_state:null
  },

  onLoad(e) {
    console.log("物品id",e.id)
    console.log("type:",e.type)
    console.log("page_state:",e.ps)
    sid = e.id
    if (e.type=="true") {
      this.setData({
        type:"detail",
        page_state: e.ps
      })
      DB.doc(sid).get()
      .then(res=>{
        console.log("物品信息",res.data.pic1)
        console.log("state",this.data.page_state)
        this.setData({
          lost_name:res.data.good_name,
          category_lab_msg:res.data.category_lab_msg.name + res.data.category_lab_msg.title,
          lost_number:res.data.lost_number,
          get_time:res.data.get_time,
          get_place:res.data.get_place,
          other:res.data.other,
          src:res.data.pic1,
          judge:1,
          link_man:res.data.name,
          link_phone:res.data.phone
        })
      })
      .catch(err=>{
        console.log(err)
      })
    } else {
      this.setData({
        type:"add"
      })
    }
  },

  onShow:function(options)
{
  this.setData({
    category_lab_msg_name : getApp().globalData.globalData_category_value.name,
    category_lab_msg_title : getApp().globalData.globalData_category_value.title,
    category_lab_msg : getApp().globalData.globalData_category_value.name+" · "+getApp().globalData.globalData_category_value.title
  })
  
  
},

  //上传图片
  f0: function(event){
    let that = this;
    // var that_ = this;

    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function(res){
        console.log("选择成功",res)
        that.setData({
          // src:res.tempFilePaths[0],
          src_list:res.tempFilePaths,
          judge:res.tempFilePaths["length"],
          show_expic:false,
          show_newpic:true,   
         })
        var src_list=res.tempFilePaths
        // var judge=res.tempFilePaths["length"]
        console.log("src_list",src_list)
        console.log("show_expic:",that.data.show_expic)
        src_list.forEach((item,idx)=>{
          var fileName=Date.now()+"_"+idx;
          that.uploadImg(fileName,item)
        })
        },
    })
    that.uploadImg()
  },

//上传图片到云开发
uploadImg(fileUrl,path){
  var that = this
  wx.cloud.uploadFile({
    cloudPath: fileUrl+'example.png',
    filePath: path,
    success: res => {
      pic=res.fileID
       console.log("上传成功",res)
       this.setData({
        // img_f1:res.fileID
        src:res.fileID
      })
       console.log("照片",pic)
      console.log("cloundPath",this.data.src)
      // this.setData({
      //   pic: res.fileID
      // })    
    },
    fail: console.error
  })
},
//点击预览图片
f1:function(event){
  let currentUrl = this.data.img_f1
  var dataArray = [];
  dataArray[0] = currentUrl
  wx.previewImage({
     current: dataArray[0], // 当前显示图片的http链接
     urls: dataArray, // 需要预览的图片http链接列表
    success:function(res){
      console.log("1111",res)
    }
  })
},

name(event){
  console.log(event.detail.value)
  lost_name = event.detail.value
  this.setData({
    lost_name:lost_name
  })
},

category(e){
  var that = this
  wx.navigateTo({
    url: '../../pages/category_add/category_add',
    // success(res){
    //   that.setData({
    //     category_lab_msg:getApp().globalData.globalData_category_value
    //   })
    // }
  })
  // var category_lab_msg = getApp().globalData.globalData_lost_time
  },

number(event){
  console.log(event.detail.value)
  lost_number = event.detail.value
  this.setData({
    lost_number:lost_number
  })
},

time(event){
  console.log(event.detail.value)
  get_time = event.detail.value
  this.setData({
    get_time:get_time
  })
},

cl_n(event) {
  console.log(event.detail.value)
  get_cln = event.detail.value
  this.setData({
    get_cln:get_cln
  })
},

cl_p(event) {
  console.log(event.detail.value)
  get_clp = event.detail.value
  this.setData({
    get_clp:get_clp
  })
},

place(event){
  console.log(event.detail.value)
  get_place = event.detail.value
  this.setData({
    get_place:get_place  
  })
},

other(event){
  console.log(event.detail.value)
  other = event.detail.value
  this.setData({
    other:other  
  })
},

  addData_last() {
    if (lost_name=='' || lost_name==null || this.data.src=='' || this.data.src==null ) {
      wx.showToast({
        title: '信息都要填写哟~',
        icon: 'none',
        duration: 2000 
      })
    } else {
    // console.log("losttime",getApp().globalData.globalData_lost_time)
    wx.showLoading({
      title: "提交中",
    })
    DB.add({
      data:{
        good_name:this.data.lost_name, 
        lost_number:this.data.lost_number, 
        get_time:this.data.get_time, 
        get_place:this.data.get_place, 
        other:this.data.other,
        pic1:this.data.src,
        category_lab_msg:getApp().globalData.globalData_category_value,
      //  named:named,
        count:this.data.count,
        audit:false,
        name:"暂无",
        phone:"暂无"
      },
      success(res){
        console.log("添加成功",res)
        wx.showToast({
          title: '提交成功',
          icon: 'success',
          duration: 2000
          })
          setTimeout(function() {
            wx.navigateBack({
              url:'/pages/station/station'
            })
          },1000)

      },
      fail(res){
        console.log("添加失败",res)
        wx.showToast({
          title: '提交失败',
          icon: 'error',
          duration: 2000
          })
      },
    })
    }
 
  },

  delete_data(e) {
    var that = this
    if(!that.data.page_state) {
      wx.showToast({
        title: '该物品已被取走',
      })
    } else {
      console.log("目标物品id",sid)
      that.setData({
        s_record:true
      })
    }
  },

  modify_data(e) {
    console.log('跳转至修改',e)
    console.log('即将传值：',e.currentTarget.dataset.id)
    wx.navigateTo({
      url: '/pages/modify_storage/modify_storage?id=' + e.currentTarget.dataset.id,
    })
  },

upData:function(e){
  console.log("losttime",getApp().globalData.globalData_lost_time)
  wx.showModal({
    title:"提示",
    content:"是否确认修改信息",
    success:(res)=> {
      console.log(res)
      if (res.confirm) {
        var that = this
        that.updata_func()
      }
      else if (res.cancel) {
        console.log("取消",)
      }
    }
  })
},

updata_func() {
  console.log("pic",this.data.src)
  wx.cloud.database().collection('lost_storage')
  .doc(sid)
  .update({
    data:{
      get_time:this.data.get_time,
      get_place:this.data.get_place,
      lost_number:this.data.lost_number,
      good_name:this.data.lost_name, 
      other:this.data.other,
      pic1:this.data.src,
      category_lab_msg:getApp().globalData.globalData_category_value,
    },
    success(res){
      console.log("修改成功",res)
      wx.showToast({
        title: '修改成功',
        icon: 'success',
        success:function() {
          setTimeout(function() {
            wx.navigateBack({
              url:'/pages/station/station'
            })
          },1000)
        }
      })
    },
    fail(res){
      console.log("添加失败",res)
      wx.showToast({
        title: '提交失败',
        icon: 'error',
        duration: 2000
        })
    },
  })
},

get_account(e) {
  console.log("打印账号",e.detail.value)
  this.setData({
    account:e.detail.value
  })
},

get_password(e) {
  console.log("打印密码",e.detail.value)
  this.setData({
    password:e.detail.value
  })
},

onCancel() {
  this.setData({
    s_record:false
  })
},

onConfirm() {
  var that = this
  wx.showModal({
    title:"提示",
    content:"是否下架该失物信息",
    success(res) {
      console.log(res)
      if (res.confirm && that.data.account!==null && !that.data.password!==null) {
        wx.cloud.database().collection('lost_storage')
        .doc(sid).update({
          data:{
            state:false,
            name:that.data.account,
            phone:that.data.password
          }
        })
        .then(res=>{
          console.log("下架成功",res)
          wx.showToast({
            title: '下架成功',
            icon: 'success',
            success:function() {
              setTimeout(function() {
                wx.navigateBack({
                  url:'/pages/station/station'
                })
              },1000)
            }
          })
        })
        .catch(err =>{
          console.log("删除失败",err)
        })
      } else {
        wx.showToast({
          title: '请输入完整信息',
        })
      }
    }
  })
},

})