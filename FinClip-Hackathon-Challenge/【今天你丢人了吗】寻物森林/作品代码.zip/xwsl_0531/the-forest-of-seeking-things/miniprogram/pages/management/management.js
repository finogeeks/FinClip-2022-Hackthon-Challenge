// pages/management/management.js
Page({
  data: {
    Administrator:{},
    show: false,
    duration: 240,
    position: 'right',
    round: true,
    overlay: true,
    customStyle: '',
    overlayStyle: '',
  },

  onLoad(options) {
    console.log("管理员信息",options)
    this.setData({
      Administrator:options
    })
  },

  go_check() {
    wx.navigateTo({
      url: '/pages/check/check',
    })
  },

  go_station() {
    wx.navigateTo({
      url: '/pages/station/station',
    })
  },

  go_off_tweet() {
    console.log("拉起弹窗")
    const position = "bottom"
    let customStyle = ''
    let duration = this.data.duration
    switch(position) {
      case 'top':
      case 'bottom': 
        customStyle = 'height: 40%;'
        break
      case 'right':
        break
    }
    this.setData({
      position,
      show: true,
      customStyle,
      duration
    })
  },

  change_subfield() {
    wx.navigateTo({
      url: '/pages/off_tweet/off_tweet',
    })
  },

  change_banner() {
    wx.navigateTo({
      url: '/pages/banner_t/banner_t',
    })
  },

  weekly_topic() {
    wx.showModal({
      title:版块待开发
    })
  }
})