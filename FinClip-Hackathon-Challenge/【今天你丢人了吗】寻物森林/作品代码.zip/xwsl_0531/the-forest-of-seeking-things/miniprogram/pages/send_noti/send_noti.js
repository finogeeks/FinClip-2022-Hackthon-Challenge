// pages/send_noti/send_noti.js
let name = ''
let contact = ''
let place = ''
let remark = ''

Page({
  data: {

  },

  onLoad: function (options) {

  },

  //获取联系人
  getName(e) {
    console.log(e)
    name = e.event.value
  },

  //获取联系方式
  getContact(e) {
    console.log(e)
    contact = e.event.value
  },

  //获取地点
  getPlace(e) {
    console.log(e)
    place = e.event.value
  },

  //获取备注
  getRemark(e) {
    console.log(e)
    remark = e.event.value
  },

  //发送消息给单个用户
  sendOne() {
    if (
      name==null || name=='' || contact==null || contact=='' || place==null || place=='' || remark==null || remark==''
    ){
      wx.showToast({
        icon:'none',
        title: '还有选项没有输入',
      })
      return
    }
    wx.cloud.callFunction({
      name: "fasong",
      data: {
        openid:"oXbDP4pqu8BI33jmlLa1R7-Ys9tw",
        name:name,
        contact:contact,
        place:place,
        remark:remark
      }
    }).then(res => {
      console.log("发送成功",res)
    }).catch(err => {
      console.log("发送失败",err)
    })
  },
})