// pages/category/category.js
const db = wx.cloud.database({
  env: 'cloud1-2g7s81h60f3fd184'
})
Page({
  data: {
    category: [],
    toView: "cw",
    curIndex: 0,
    isScroll: false,
    typelist:[]
  },


  category_lab:function(e) {
    console.log(e)
    console.log(e.currentTarget.dataset.title)
    var category_value = e.currentTarget.dataset
    wx.reLaunch({
      url: '../station/station?title=' + e.currentTarget.dataset.name +'·'+ e.currentTarget.dataset.title,
    })
  },

  searchGood: function (e) {

    console.log(this.data.typelist)
    var search_key = e.detail.value.keyword
    console.log(search_key)
    // wx.showToast({
    //   title: "Loading...",
    //   icon: "loading",
    //   duration: 390000
    // })
    var searched = []
    for (var index in this.data.typelist) {
      // console.log(this.data.typelist[index].goods)
      // for (var index in )
      for (var i in this.data.typelist[index].goods) {
        // 所有商品到内容
        var goods_title = this.data.typelist[index].goods[i].title
        if (goods_title.indexOf(search_key) >= 0) {
          var goods = this.data.typelist[index].goods[i]
          console.log(this.data.typelist[index].goods[i])
          searched = searched.concat(goods)

        }
      }
    }
    console.log("searched=", searched)
    var search_results = JSON.stringify(searched)
    wx.navigateTo({
      url: '/pages/searchs/searchs?search_results=' + search_results,
    })
              // 增加进商品搜索结果
              

  },



  // 调取数据库的函数
  get_database: function(){

    db.collection('typelist').get({
      success:res=>{
        console.log("typelist:?",res.data)
        var typelist = res.data
        this.setData({
          typelist : res.data[0].typelist

        })
        console.log("typelist:",typelist)
        console.log("typelist[id]",typelist[0]['id'])
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.get_database()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  switchTab: function (e) {
    const self = this;
    console.log(e)

    this.setData({
      isScroll: true
    })
    // curIndex 的值为当前点击的dataset 中index的值
    // 
    setTimeout(function () {
      self.setData({
        toView: e.currentTarget.dataset.id,
        curIndex: e.currentTarget.dataset.index
      })
      
    }, 0)
    setTimeout(function () {
      self.setData({
        isScroll: false
      })
    }, 1)

  },
  /**
   * 生命周期函数--监听页面显示
   */
  // onShow: function () {
  //   console.log("cate_id=", getApp().globalData.cate_id)
  //   console.log("cate_toView=", getApp().globalData.cate_toView)
  //   this.setData({
  //     curIndex: getApp().globalData.cate_id,
  //     toView: getApp().globalData.cate_toView,
  //   })

  // },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})