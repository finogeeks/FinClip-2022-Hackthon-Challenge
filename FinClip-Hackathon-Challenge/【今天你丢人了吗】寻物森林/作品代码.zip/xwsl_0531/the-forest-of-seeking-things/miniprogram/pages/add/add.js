// pages/up/up.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    dialogShow: false,
    showOneButtonDialog: false,
    dialogShow2: false,
    showOneButtonDialog2: false,
    buttons: [{text: '取消'}, {text: '确定'}],
    oneButton: [{text: '确定'}],
  },

  // 弹窗sth
  openConfirm: function () {
    this.setData({
        dialogShow: true
    })
},

tapDialogButton(e) {
    this.setData({
        dialogShow: false,
        showOneButtonDialog: false
    })
},
tapDialogButton2(e) {
  this.setData({
      dialogShow2: false,
      showOneButtonDialog2: false
  })
},

tapOneDialogButton(e) {
    this.setData({
        showOneButtonDialog: true
    })
},

dialog(){

  this.setData({
    dialogShow : true
  })
},

dialog2(){

  this.setData({
    dialogShow2 : true
  })
},
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})