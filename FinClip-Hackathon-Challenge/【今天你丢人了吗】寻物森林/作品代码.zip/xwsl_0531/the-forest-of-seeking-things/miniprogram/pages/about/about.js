// pages/about/about.js
Page({

  data: {
    forest:true,
    memory:"https://www.bilibili.com/video/BV1Sb4y1k7tu/",
    img_610:"cloud://cloud1-2g7s81h60f3fd184.636c-cloud1-2g7s81h60f3fd184-1306014217/610.jpg"
  },

  onLoad: function (options) {
    if(options.tap == "egg") {
      this.setData({
        forest:false
      })
    }
  },

  onShareAppMessage() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    })
  },
  
  onShareTimeline(e) {
    console.log(e)
    return {
      title: '分享至朋友圈',
      path:''
    }
  },
})