// upmsg/upmag.js

// var pic_list = new Array();
var pic =""
var app = getApp()

const DB = wx.cloud.database().collection("try_5-10")
const db = wx.cloud.database().collection("u_rank")

let time = ""
let place = ""
let name = ""
let other = ""
let moren_lab1 = ""
let moren_lab2 = ""
let lab = []
var call=""
var named=""
var award=""
var lost_name=""
var lost_moren_lab1=""
var lost_moren_lab2=""
var lost_placename = ""
var lost_place_latitude =""
var lost_place_longitude = ""
var category_lab_msg = ""
var state = "寻找中"
var src=""

Page({
  data:{
    dialogShow: false,
        showOneButtonDialog: false,
        count:0,
        infos:[],
        buttons: [{text: '取消'}, {text: '确定'}],
        oneButton: [{text: '确定'}],
        img_f1:[],
        lost_name:"丢失的物品名称",
        lost_moren_lab1:"物品特征",
        lost_moren_lab2:"物品特征",
    losttime : "丢失物品时间",
    lost_placename : "丢失物品地点",
    category_lab_msg : "失物分类",
    rank:[],
    state : "寻找中",
    pic_src:"",
    date:new Date(),
    judge:"",
    open_id:[],
    datab:[],
    options:[
      
    ] ,//选项列表

    options_qest:[

    ]//问题列表
  },
  // 弹窗sth
  openConfirm: function () {
    this.setData({
        dialogShow: true
    })
},

tapDialogButton(e) {
    this.setData({
        dialogShow: false,
        showOneButtonDialog: false
    })
},

tapOneDialogButton(e) {
    this.setData({
        showOneButtonDialog: true
    })
},

  //上传图片
  f0: function(event){
    let that = this;
    var that_ = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function(res){
        console.log("选择成功",res)
        that_.setData({
          src:res.tempFilePaths[0],
          src_list:res.tempFilePaths,
          judge:res.tempFilePaths["length"]   
         })
        var src_list=res.tempFilePaths
        console.log("src_list",src_list)
        src_list.forEach((item,idx)=>{
          var fileName=Date.now()+"_"+idx;
          that.uploadImg(fileName,item)
        })
        },
    })
    that.uploadImg()
  },

  // pic_api: function(e){    // 这里的imageData是图片转换成base64格式的数据

  //   var that = this;
  //   const detectUrl = `https://aip.baidubce.com/api/v1/solution/direct/imagerecognition/combination?access_token=${that.data.baiduToken}`    // baiduToken是已经获取的access_Token
  //   // console.log('123',detectUrl) 
  //     return new Promise(function(resolve,reject){        
  //     wx.request({            
  //       url: detectUrl,            
  //       data: {                
  //         image: e,
  //         scenes:["advanced_general","multi_object_detect"],
                    
  //       },            
  //       method: 'POST',            
  //       dataType: 'json',            
  //       header:{                
  //         'content-type': 'application/json'    // 必须的        
  //       },            
  //       success: function(res, resolve){              
  //         console.log('调用图像识别APIsuccess：',res.data);              
  //         // var word = res.data.words_result[0].words              	
  //         // console.log(word);            
  //       },            
  //       fail : function(res,reject){              
  //         console.log('调用图像识别APIfail：',res.data);           			},            
  
  //     })
  //   }) 
  // },

//上传图片到云开发
uploadImg(fileUrl,path){
  var that = this
  wx.cloud.uploadFile({
    cloudPath: fileUrl+'example.png',
    filePath: path,
    success: res => {
      pic=res.fileID
       console.log("上传成功",res)
       this.setData({
        img_f1:res.fileID
      })
       console.log("照片",pic)
       setTimeout(function () {
        that.get_pichttp(pic)
       }, 1000)
      console.log("cloundPath",cloundPath)
      this.setData({
        pic: res.fileID
      })    
    },
    fail: console.error
  })
},

// 获取临时外链
get_pichttp:function(pic){
  var that = this
  // 获取临时外链
  wx.cloud.getTempFileURL({
    fileList: [{
      fileID: pic,
      maxAge: 60 * 60, // one hour
    }]
  }).then(res => {
    // get temp file URL

    console.log("临时外链",res.fileList[0].tempFileURL)
     setTimeout(function () {
    // that.Auzare_api(res.fileList[0].tempFileURL)
    that.server(res.fileList[0].tempFileURL)
   }, 1000) //延迟时间 这里是1秒
  }).catch(error => {
    // handle error
    console.log("获取外链失败")
  })
 
  
},

server:function(e){
  var that = this
  console.log("server-img",e)
  wx.request({
    url: 'https://xuzhichao.cn/Azure_CV_API', //仅为示例，并非真实的接口地址
    data: {
      url:e
    },
    method: 'POST',  
    header: {
      'content-type': 'application/json' // 默认值
    },
    success (res) {
      console.log("all_msg",res.data)
      console.log("json_msg",JSON.parse(res.data))
      console.log("物品名称1",JSON.parse(res.data).categories[0].name)
      // console.log("物品名称-英",JSON.parse(res.data).objects[0].object)
      console.log("物品标签",JSON.parse(res.data).tags[0].name)
      console.log("物品标签",JSON.parse(res.data).tags[1].name)

      moren_lab1 = JSON.parse(res.data).tags[0].name
      moren_lab2 = JSON.parse(res.data).tags[1].name


      if(JSON.parse(res.data).objects.length==0){
        that.setData({
          dialogShow : true
        })
      }
        else{
      that.setData({
        // lost_name : name,
        lost_moren_lab1:moren_lab1,
        lost_moren_lab2:moren_lab2
      })
      that.translate(JSON.parse(res.data).objects[0].object)
      }
    }
  })
},

//点击预览图片
  f1:function(event){
    let currentUrl = this.data.img_f1
    var dataArray = [];
    dataArray[0] = currentUrl
    wx.previewImage({
       current: dataArray[0], // 当前显示图片的http链接
       urls: dataArray, // 需要预览的图片http链接列表
      success:function(res){
        console.log("1111",res)
      }
    })
  },


// 百度翻译API
  translate:function(e){
    var that = this
    var q = e     
            var from = 'en'
            var to = 'zh'
            //注册获得appid和密匙
            var appid = '20210520000835818'
            var key = '3Ufipaq7_WjLQ6VvpoDS'
            var salt = '1435660288' //随机数,按文档要求应该是随机数，但学习方便就使用了一个固定
            var string = appid + q + salt + key
            var sign = this.MD5(string)  //MD5是一个写好的加密函数
  
    wx.request({
      url: 'https://fanyi-api.baidu.com/api/trans/vip/translate',
      data: {
        q,
        from,
        to,
        appid,
        salt,
        sign
      },
      success: res => {
        console.log('success:', res)
        console.log('结果:',res.data.trans_result[0].dst)
        that.setData({
          lost_name: res.data.trans_result[0].dst,
        })
        console.log('中文名称',this.data.lost_name)

      },
      fail: res => {
       console.log('fail:', res)
      }
   })
  
  },
  
  MD5: function (string) {
  
    function RotateLeft(lValue, iShiftBits) {
      return (lValue << iShiftBits) | (lValue >>> (32 - iShiftBits));
    }
  
    function AddUnsigned(lX, lY) {
      var lX4, lY4, lX8, lY8, lResult;
      lX8 = (lX & 0x80000000);
      lY8 = (lY & 0x80000000);
      lX4 = (lX & 0x40000000);
      lY4 = (lY & 0x40000000);
      lResult = (lX & 0x3FFFFFFF) + (lY & 0x3FFFFFFF);
      if (lX4 & lY4) {
        return (lResult ^ 0x80000000 ^ lX8 ^ lY8);
      }
      if (lX4 | lY4) {
        if (lResult & 0x40000000) {
          return (lResult ^ 0xC0000000 ^ lX8 ^ lY8);
        } else {
          return (lResult ^ 0x40000000 ^ lX8 ^ lY8);
        }
      } else {
        return (lResult ^ lX8 ^ lY8);
      }
    }
  
    function F(x, y, z) {
      return (x & y) | ((~x) & z);
    }
  
    function G(x, y, z) {
      return (x & z) | (y & (~z));
    }
  
    function H(x, y, z) {
      return (x ^ y ^ z);
    }
  
    function I(x, y, z) {
      return (y ^ (x | (~z)));
    }
  
    function FF(a, b, c, d, x, s, ac) {
      a = AddUnsigned(a, AddUnsigned(AddUnsigned(F(b, c, d), x), ac));
      return AddUnsigned(RotateLeft(a, s), b);
    };
  
    function GG(a, b, c, d, x, s, ac) {
      a = AddUnsigned(a, AddUnsigned(AddUnsigned(G(b, c, d), x), ac));
      return AddUnsigned(RotateLeft(a, s), b);
    };
  
    function HH(a, b, c, d, x, s, ac) {
      a = AddUnsigned(a, AddUnsigned(AddUnsigned(H(b, c, d), x), ac));
      return AddUnsigned(RotateLeft(a, s), b);
    };
  
    function II(a, b, c, d, x, s, ac) {
      a = AddUnsigned(a, AddUnsigned(AddUnsigned(I(b, c, d), x), ac));
      return AddUnsigned(RotateLeft(a, s), b);
    };
  
    function ConvertToWordArray(string) {
      var lWordCount;
      var lMessageLength = string.length;
      var lNumberOfWords_temp1 = lMessageLength + 8;
      var lNumberOfWords_temp2 = (lNumberOfWords_temp1 - (lNumberOfWords_temp1 % 64)) / 64;
      var lNumberOfWords = (lNumberOfWords_temp2 + 1) * 16;
      var lWordArray = Array(lNumberOfWords - 1);
      var lBytePosition = 0;
      var lByteCount = 0;
      while (lByteCount < lMessageLength) {
        lWordCount = (lByteCount - (lByteCount % 4)) / 4;
        lBytePosition = (lByteCount % 4) * 8;
        lWordArray[lWordCount] = (lWordArray[lWordCount] | (string.charCodeAt(lByteCount) << lBytePosition));
        lByteCount++;
      }
      lWordCount = (lByteCount - (lByteCount % 4)) / 4;
      lBytePosition = (lByteCount % 4) * 8;
      lWordArray[lWordCount] = lWordArray[lWordCount] | (0x80 << lBytePosition);
      lWordArray[lNumberOfWords - 2] = lMessageLength << 3;
      lWordArray[lNumberOfWords - 1] = lMessageLength >>> 29;
      return lWordArray;
    };
  
    function WordToHex(lValue) {
      var WordToHexValue = "",
        WordToHexValue_temp = "",
        lByte, lCount;
      for (lCount = 0; lCount <= 3; lCount++) {
        lByte = (lValue >>> (lCount * 8)) & 255;
        WordToHexValue_temp = "0" + lByte.toString(16);
        WordToHexValue = WordToHexValue + WordToHexValue_temp.substr(WordToHexValue_temp.length - 2, 2);
      }
      return WordToHexValue;
    };
  
    function Utf8Encode(string) {
      string = string.replace(/\r\n/g, "\n");
      var utftext = "";
  
      for (var n = 0; n < string.length; n++) {
  
        var c = string.charCodeAt(n);
  
        if (c < 128) {
          utftext += String.fromCharCode(c);
        } else if ((c > 127) && (c < 2048)) {
          utftext += String.fromCharCode((c >> 6) | 192);
          utftext += String.fromCharCode((c & 63) | 128);
        } else {
          utftext += String.fromCharCode((c >> 12) | 224);
          utftext += String.fromCharCode(((c >> 6) & 63) | 128);
          utftext += String.fromCharCode((c & 63) | 128);
        }
  
      }
  
      return utftext;
    };
  
    var x = Array();
    var k, AA, BB, CC, DD, a, b, c, d;
    var S11 = 7,
      S12 = 12,
      S13 = 17,
      S14 = 22;
    var S21 = 5,
      S22 = 9,
      S23 = 14,
      S24 = 20;
    var S31 = 4,
      S32 = 11,
      S33 = 16,
      S34 = 23;
    var S41 = 6,
      S42 = 10,
      S43 = 15,
      S44 = 21;
  
    string = Utf8Encode(string);
  
    x = ConvertToWordArray(string);
  
    a = 0x67452301;
    b = 0xEFCDAB89;
    c = 0x98BADCFE;
    d = 0x10325476;
  
    for (k = 0; k < x.length; k += 16) {
      AA = a;
      BB = b;
      CC = c;
      DD = d;
      a = FF(a, b, c, d, x[k + 0], S11, 0xD76AA478);
      d = FF(d, a, b, c, x[k + 1], S12, 0xE8C7B756);
      c = FF(c, d, a, b, x[k + 2], S13, 0x242070DB);
      b = FF(b, c, d, a, x[k + 3], S14, 0xC1BDCEEE);
      a = FF(a, b, c, d, x[k + 4], S11, 0xF57C0FAF);
      d = FF(d, a, b, c, x[k + 5], S12, 0x4787C62A);
      c = FF(c, d, a, b, x[k + 6], S13, 0xA8304613);
      b = FF(b, c, d, a, x[k + 7], S14, 0xFD469501);
      a = FF(a, b, c, d, x[k + 8], S11, 0x698098D8);
      d = FF(d, a, b, c, x[k + 9], S12, 0x8B44F7AF);
      c = FF(c, d, a, b, x[k + 10], S13, 0xFFFF5BB1);
      b = FF(b, c, d, a, x[k + 11], S14, 0x895CD7BE);
      a = FF(a, b, c, d, x[k + 12], S11, 0x6B901122);
      d = FF(d, a, b, c, x[k + 13], S12, 0xFD987193);
      c = FF(c, d, a, b, x[k + 14], S13, 0xA679438E);
      b = FF(b, c, d, a, x[k + 15], S14, 0x49B40821);
      a = GG(a, b, c, d, x[k + 1], S21, 0xF61E2562);
      d = GG(d, a, b, c, x[k + 6], S22, 0xC040B340);
      c = GG(c, d, a, b, x[k + 11], S23, 0x265E5A51);
      b = GG(b, c, d, a, x[k + 0], S24, 0xE9B6C7AA);
      a = GG(a, b, c, d, x[k + 5], S21, 0xD62F105D);
      d = GG(d, a, b, c, x[k + 10], S22, 0x2441453);
      c = GG(c, d, a, b, x[k + 15], S23, 0xD8A1E681);
      b = GG(b, c, d, a, x[k + 4], S24, 0xE7D3FBC8);
      a = GG(a, b, c, d, x[k + 9], S21, 0x21E1CDE6);
      d = GG(d, a, b, c, x[k + 14], S22, 0xC33707D6);
      c = GG(c, d, a, b, x[k + 3], S23, 0xF4D50D87);
      b = GG(b, c, d, a, x[k + 8], S24, 0x455A14ED);
      a = GG(a, b, c, d, x[k + 13], S21, 0xA9E3E905);
      d = GG(d, a, b, c, x[k + 2], S22, 0xFCEFA3F8);
      c = GG(c, d, a, b, x[k + 7], S23, 0x676F02D9);
      b = GG(b, c, d, a, x[k + 12], S24, 0x8D2A4C8A);
      a = HH(a, b, c, d, x[k + 5], S31, 0xFFFA3942);
      d = HH(d, a, b, c, x[k + 8], S32, 0x8771F681);
      c = HH(c, d, a, b, x[k + 11], S33, 0x6D9D6122);
      b = HH(b, c, d, a, x[k + 14], S34, 0xFDE5380C);
      a = HH(a, b, c, d, x[k + 1], S31, 0xA4BEEA44);
      d = HH(d, a, b, c, x[k + 4], S32, 0x4BDECFA9);
      c = HH(c, d, a, b, x[k + 7], S33, 0xF6BB4B60);
      b = HH(b, c, d, a, x[k + 10], S34, 0xBEBFBC70);
      a = HH(a, b, c, d, x[k + 13], S31, 0x289B7EC6);
      d = HH(d, a, b, c, x[k + 0], S32, 0xEAA127FA);
      c = HH(c, d, a, b, x[k + 3], S33, 0xD4EF3085);
      b = HH(b, c, d, a, x[k + 6], S34, 0x4881D05);
      a = HH(a, b, c, d, x[k + 9], S31, 0xD9D4D039);
      d = HH(d, a, b, c, x[k + 12], S32, 0xE6DB99E5);
      c = HH(c, d, a, b, x[k + 15], S33, 0x1FA27CF8);
      b = HH(b, c, d, a, x[k + 2], S34, 0xC4AC5665);
      a = II(a, b, c, d, x[k + 0], S41, 0xF4292244);
      d = II(d, a, b, c, x[k + 7], S42, 0x432AFF97);
      c = II(c, d, a, b, x[k + 14], S43, 0xAB9423A7);
      b = II(b, c, d, a, x[k + 5], S44, 0xFC93A039);
      a = II(a, b, c, d, x[k + 12], S41, 0x655B59C3);
      d = II(d, a, b, c, x[k + 3], S42, 0x8F0CCC92);
      c = II(c, d, a, b, x[k + 10], S43, 0xFFEFF47D);
      b = II(b, c, d, a, x[k + 1], S44, 0x85845DD1);
      a = II(a, b, c, d, x[k + 8], S41, 0x6FA87E4F);
      d = II(d, a, b, c, x[k + 15], S42, 0xFE2CE6E0);
      c = II(c, d, a, b, x[k + 6], S43, 0xA3014314);
      b = II(b, c, d, a, x[k + 13], S44, 0x4E0811A1);
      a = II(a, b, c, d, x[k + 4], S41, 0xF7537E82);
      d = II(d, a, b, c, x[k + 11], S42, 0xBD3AF235);
      c = II(c, d, a, b, x[k + 2], S43, 0x2AD7D2BB);
      b = II(b, c, d, a, x[k + 9], S44, 0xEB86D391);
      a = AddUnsigned(a, AA);
      b = AddUnsigned(b, BB);
      c = AddUnsigned(c, CC);
      d = AddUnsigned(d, DD);
    }
  
    var temp = WordToHex(a) + WordToHex(b) + WordToHex(c) + WordToHex(d);
  
    return temp.toLowerCase();
  },


// 动态变化标签
//添加选项
addOption(e){
  let options = this.data.options
  console.log(options)
  options.push({value:''})
  console.log(options.length)
  var len = options.length
  if(len<=3){
    this.setData({
        options: options
      })
  }
  

},
//文本输入
bindinput(e){
  console.log(e)
  let index = e.currentTarget.dataset.id //索引位置
  let value = e.detail.value //输入的内容
  let options = this.data.options
  options[index].value = value
//   for(var i =0;i<index;i++){
//     arr.push(lab[options[i].value]);
 
// };
  this.setData({
    options: options,
    lab:{}
  })
},
//删除选项
delOption(e){
  let index = e.currentTarget.dataset.id //索引位置
  let options = this.data.options
  options.splice(index,1)

  this.setData({
    options: options
  })

},

// 动态变化问题表单
//添加选项
addOption_qest(e){
  let options_qest = this.data.options_qest
  console.log(options_qest)
  options_qest.push({value:''})
  console.log(options_qest.length)
  var len_qest = options_qest.length
  if(len_qest<=3){
    this.setData({
        options_qest: options_qest
      })
  }
  
},
//文本输入
bindinput_qest1(e){
  console.log(e)
  let index_qest1 = e.currentTarget.dataset.id //索引位置
  let value_qest1 = e.detail.value //输入的内容
  let options_qest1 = this.data.options_qest1
  options_qest1[index_qest1].value = value_qest1
  this.setData({
    options_qest1: options_qest1
  })
},

bindinput_qest2(e){
  console.log(e)
  let index_qest2 = e.currentTarget.dataset.id //索引位置
  let value_qest2 = e.detail.value //输入的内容
  let options_qest2 = this.data.options_qest2
  options_qest2[index_qest2].value = value_qest2
  this.setData({
    options_qest2: options_qest2
  })
},
//删除选项
delOption_qest(e){
  let index_qest = e.currentTarget.dataset.id //索引位置
  let options_qest = this.data.options_qest
  options_qest.splice(index_qest,1)

  this.setData({
    options_qest: options_qest
  })

},
// 图像识别API——Auzare
Auzare_api: function(pic_src){   
	var that = this;

  const url = 'https://zjlcomputervision.cognitiveservices.azure.com/vision/v3.0/analyze?visualFeatures=Categories,Description,Color,Objects,Tags&language=zh'
 	// return new Promise(function(resolve,reject){        
		wx.request({            
			url: url,            
			data: {                
        url: pic_src,
        // scenes:["advanced_general","multi_object_detect"],
            
			},            
			method: 'POST',            
			dataType: 'json',            
			header:{                
        'Content-Type': 'application/json' ,   // 必须的   
        'Ocp-Apim-Subscription-Key': 'b0ce73a0b9c4486985f1e556d8052fdd' ,
       
			},            
			success: function(res){              
        console.log('调用Auzare图像识别APIsuccess：',res.data);
        console.log('对象识别：',res.data.objects);
        
        if(res.data.objects.length==0){
          that.setData({
            dialogShow : true
          })
        }
          else{
            name = res.data.objects[0].object
            moren_lab1 = res.data.tags[0].name
            moren_lab2 = res.data.tags[1].name
            console.log('物品名',name)
            console.log('物品tags',moren_lab1)
            console.log('物品tags',moren_lab2)    
            that.setData({
              // lost_name : name,
              lost_moren_lab1:moren_lab1,
              lost_moren_lab2:moren_lab2
            })
        that.translate(name)
        }    
			},            
			fail : function(err){              
        console.log('调用Auzare图像识别APIfail：',err)   
      },            
    })
},



onLoad: function (e) {
  this.getOpenid()
  var that =this
  DB.get({
    success(res) {
      console.log("获取数据",res)
      that.setData({
        datab:res.data
      })
    }
  })

  db.get({
    success(res) {
      console.log("获取数据",res)
      that.setData({
        rank:res.data
      })
    }
  })
},

onShow:function(options)
{
  // var category_lab_msg_name=getApp().globalData.globalData_category_value.name
  // var category_lab_msg_tite = getApp().globalData.globalData_category_value.title
  // console.log("m",getApp().globalData.globalData_category_value.name+" · "+getApp().globalData.globalData_category_value.title)
  this.setData({
    category_lab_msg_name : getApp().globalData.globalData_category_value.name,
    category_lab_msg_title : getApp().globalData.globalData_category_value.title,
    category_lab_msg : getApp().globalData.globalData_category_value.name+" · "+getApp().globalData.globalData_category_value.title
  })
  
  
},

//获取用户输入的信息
time(event){
  console.log(event.detail.value)
  time = event.detail.value
},
place(event){
  var that = this
    wx.chooseLocation({
      success(res) {
        console.log(res.name);
        lost_placename = res.name
        lost_place_latitude = res.latitude
        lost_place_longitude = res.longitude

        that.setData({
          lost_placename:lost_placename,
          losttime:getApp().globalData.globalData_lost_time
        })
      },
    })

},
// 用户使用地图授权
openMap:function(e){
  var that = this
  wx.getSetting({
      success(res){
      //这里判断是否有地位权限
        if (!res.authSetting['scope.userLocation']) {
          wx.authorize({

            scope: 'scope.userLocation',
            success(res){
              console.log(res)

            }
          })
          wx.showModal({
            title: '提示',
            content: '请求获取位置权限',
            success:function(res){
             if(res.confirm==false){
                return false;
              }
              wx.openSetting({
                success(res) {
                  //如果再次拒绝则返回页面并提示
                  if (!res.authSetting['scope.userLocation']) {
                    wx.showToast({
                      title: '此功能需获取位置信息，请重新设置',
                      duration: 3000,
                      icon: 'none'
                    })
                  } else {
                    //允许授权，调用地图
                    that.place()
                  }
                }
              })
            }
          }) 
        } else {
        //如果有定位权限，调用地图
          that.place()
        }

      }
    
  })
},




name(event){
  console.log(event.detail.value)
  name = event.detail.value
  this.setData({
    lost_name:name
  })
},

category(e){
  var that = this
  wx.navigateTo({
    url: '../../pages/category_add/category_add',
  //   success(res){
  //   that.setData({
  //     category_lab_msg = getApp().globalData.globalData_lost_time
  // })
  // }
  })
  // var category_lab_msg = getApp().globalData.globalData_lost_time
  
  

  },


moren_qest1(event){
  console.log(event.detail.value)
  moren_qest1 = event.detail.value
},
moren_qest2(event){
  console.log(event.detail.value)
  moren_qest2 = event.detail.value
},
moren_answer1(event){
  console.log(event.detail.value)
  moren_answer1 = event.detail.value
},
moren_answer2(event){
  console.log(event.detail.value)
  moren_answer1 = event.detail.value
},
morenlab1(event){
  console.log(event.detail.value)
  moren_lab1 = event.detail.value
  this.setData({
    lost_moren_lab1:moren_lab1
  })
},
morenlab2(event){
  console.log(event.detail.value)
  moren_lab2 = event.detail.value
  this.setData({
    lost_moren_lab2:moren_lab2
  })
},
other(event){
  console.log(event.detail.value)
  other = event.detail.value
},

award(event){
  console.log(event.detail.value)
   award = event.detail.value
},
named(event){
  console.log(event.detail.value)
   named = event.detail.value
},
call(event){
  console.log(event.detail.value)
   call = event.detail.value
},



//添加数据
addData(){
  wx.showLoading({
    title: "内容审核",
    duration:800,
  })
  var that=this
  console.log("other传值",other)
  wx.cloud.callFunction({
    name:'msgcheck',
    data: {
      text: name + moren_lab1 + moren_lab2 + call + named + award + other
    },
  success(res) {
    console.log('内容审核',res)
    if (res.result.errCode == 87014) {
      wx.showToast({
        icon:'none',
        title: '存在违规文字',
      })
    }
    else if(res.result.errCode == 0) {
      console.log('内容合规')
      that.addData_last()
    }
  },
  fail(err) {
    console.log("错误反馈",err)
  }
})
  // 刷新
  // wx.reLaunch({
  //   url:"/pages/shouye/shouye",         
  // })
},

//name=="" || name==null || other=='' || other==null || moren_lab1=='' || moren_lab1==null ||
// pic=='' || pic==null || getApp().globalData.globalData_lost_time=='' || getApp().globalData.globalData_lost_time==null || call=='' || call==null || named=='' || named==null

  addData_last() {
    if (other=='' || other==null || moren_lab1=='' || moren_lab1==null || pic=='' || pic==null || getApp().globalData.globalData_lost_time=='' || getApp().globalData.globalData_lost_time==null) {
      wx.showToast({
        title: '信息都要填写哟~',
        icon: 'none',
        duration: 2000 
      })
    } else {
    // console.log("losttime",getApp().globalData.globalData_lost_time)
    wx.showLoading({
      title: "提交中",
    })
    DB.add({
      data:{
        name:this.data.lost_name, 
        other:other,
        moren_lab1:this.data.lost_moren_lab1,
        moren_lab2:this.data.lost_moren_lab2,
        pic1:pic,
        lost_placename:lost_placename,
        lost_place_latitude:lost_place_latitude,
        lost_place_longitude:lost_place_longitude,
        losttime : getApp().globalData.globalData_lost_time,
        category_lab_msg:getApp().globalData.globalData_category_value,
        call:call,
        named:named,
        state: "寻找中",
        type: "丢失",
        count:this.data.count,
        audit:false,
        audit_res:"不通过"
      },
      success(res){
        console.log("添加成功",res)
        wx.showToast({
          title: '提交成功',
          icon: 'success',
          duration: 2000
          })
          
        //   info={
        //     openid:this.data.openid,
        //     count:this.data.count
        //   },
        //  this.data.infos.push(info)
        //  that.setData({
        //    infos:this.data.infos
        //  })
        wx.switchTab({
          url: '/pages/shouye/shouye',
        })

      },
      fail(res){
        console.log("添加失败",res)
        wx.showToast({
          title: '提交失败',
          icon: 'error',
          duration: 2000
          })
      },
    })
    }
 
  },

  u_rank() {
    wx.cloud.database().collection('u_rank').add({
      data:{
        count:this.data.count
      }
    })
  },

  authorization(e) {
    let that = this
    console.log("发送者openid",this.data.open_id.result.openid)
    console.log(e)
    wx.requestSubscribeMessage({
      tmplIds: ['09jU3ntZuIv7MBPTrJJA-gcupjdYTW6ZhjZyYb68bwg','QPLrrmYm_Kt8giQiZHLJhPW-wQXxy5a4CrwgNSpMZe4'],
      success:(res)=> {
        console.log("授权成功",res)
        that.addData()
      },
      fail(err) {
        console.log("授权失败",err)
      },
      // complete() {
      //   that.addData()
      // }
    })
  },

  addGM_list() {
    console.log(this.data.good.name)
    wx.cloud.database().collection('GoodMan_list')
    .add({
      data:{
        lthing:this.data.good.name
      },
      success(res) {
        console.log("上传成功",res)
      },
      fail(err) {
        console.log("上传失败",err)
      }
    })
  },

  getOpenid() {
    wx.cloud.callFunction({
      name:"getopenid"
    }).then(res=>{
      console.log("获取openid成功",res)
      this.setData({
        open_id:res
      })
      console.log('3333',this.data.open_id)
    }).catch(err=>{
      console.log("获取失败",err)
    })
  },

})

