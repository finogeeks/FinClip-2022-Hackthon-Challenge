// miniprogram/pages/search result/search result.js
const db = wx.cloud.database({
  env: 'cloud1-2g7s81h60f3fd184'
})

Page({
  data: {
    good:{}
  },
  
  inputValue: "",        //输入框输入的值

  searchbegin: function (e) {
    let _this = this
    var data = e.currentTarget.dataset;
    _this.data.replaceValue = e.currentTarget.dataset.postname
    // _this.data.replaceValue = 
    wx: wx.setStorage({
      key: 'historyStorage',
      data: _this.data.historyStorage.concat(_this.data.inputValue).reverse(),
      data: _this.data.historyStorage.concat(_this.data.replaceValue).reverse()
    })
    // console.log(_this.data.inputValue)
    // console.log(_this.data.historyStorage)
    // console.log(data['postname'])
    if (data['postname'] == '') {
      wx.showToast({
        title: '请先输入品牌或商品',
        icon: 'none'
      })
    } else {
      wx.redirectTo({
        url: '../../commodity/commodity-search-list/index?postName=' + data['postname'] + '&searchtype=' + _this.searchtype
      })
    }
  },


  // 搜索
 searchList: function(ev){
  console.log('输入框内容?')
  let e = ev.detail;
  this.data.searchstr = e.detail.value
  console.log(this.data.searchstr,'输入框内容')
  var searchstr = this.data.searchstr //获取输入框输入内容
  this.setData({
    searchstr: e.detail.value
  })
 },//监听输入框内容


 
 endsearchList(e) {
  console.log('搜索框回调函数')
  db.collection('try_5-10')
  .where({
    name:{
      $regex:'.*'+ this.data.searchstr,
      $options: 'i'
    } //匹配输入内容
  })
  .get({
    success : res =>{
      if (res.data.length == 0) {
        wx.showModal({
          title: '提示',
          content: '暂时没找到对应答案',
          showCancel: false,
          success: function (res) { }
        })
        return;
      }
      else{
        console.log('[搜索成功]',res)
      }
      this.setData({
        good : res.data
       })
     }
   })
},//搜索回调


// 取消搜索
cancelsearch() {
  this.setData({
    searchstr: ''
  })
},
//清空搜索框
activity_clear(e) {

  this.setData({
    searchstr: ''
  })
},
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    var title = options.title
    console.log("shouye传值",options.title)
    this.getDetail(title)
  },

  getDetail(e) {
    console.log('名称',e)
    wx.cloud.database().collection('try_5-10')
    .where({
      category_lab_msg:{
        title:e
      }
    })
    .get()
    .then(res => {
      console.log('物件查询成功',res)
      this.setData({
        good:res.data
      })
    })
    .catch(res => {
      console.error('物件查询失败',res)
    })
  },

  detail(e) {
    console.log(e)
    wx.navigateTo({
      url: '/pages/sw_detail/sw_detail?id=' + e.currentTarget.dataset.id,
    })
  }
})