// pages/index/index.js
Page({
  data: {
    list:[]
  },

  onLoad: function (options) {
    this.getOpenid()
  },

  enter_ur() {
    console.log("openid传值",this.data.list)
    wx.navigateTo({
      url: '/pages/psonal_rec/psonal_rec?openid=' + this.data.list,
    })
  },

  // 获取Openid
  getOpenid() {
    wx.cloud.callFunction({
      name:"getopenid"
    }).then(res=>{
      console.log("获取openid成功",res.result.event.userInfo.openId)
      this.setData({
        list:res.result.event.userInfo.openId
      })
    }).catch(err=>{
      console.log("获取失败",err)
    })
  },
})