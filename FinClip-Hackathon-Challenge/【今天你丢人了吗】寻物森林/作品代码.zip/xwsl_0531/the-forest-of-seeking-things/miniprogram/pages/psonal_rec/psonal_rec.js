// pages/psonal_rec/psonal_rec.js
let openid=''

Page({
  data: {
    openid:"",
    good:{},
    isBindExpert:[],
    pers_id:[],
    hasUserInfo: false
  },
// 生命周期，页面加载，只执行一次
// onshow ，页面显示，每一次页面显示都会执行
  onLoad(options) {
    console.log("audio传值",options.openid)
    openid = options.openid
    // this.getDetail()
    if (openid) {
      wx.setStorageSync('p_openid',openid)
      this.setData({
        pers_id: openid,
      })
    }
  },

  onShow() {
    var user = wx.getStorageSync('p_openid');
    if(user) {
      console.log('已获取')
      this.setData({
        pers_id: user,
      })
      this.getDetail()
    }
  },


  getDetail() {
    console.log('openid',this.data.pers_id)
    wx.cloud.database().collection('try_5-10')
    .where({
      _openid:this.data.pers_id
    })
    .get()
    .then(res => {
      console.log('个人发布内容查询成功',res)
      this.setData({
        good:res.data
      })
      
    })
    .catch(res => {
      console.error('物品详情查询失败',res)
    })
  },

  modify_d(e) {
    console.log('跳转至修改',e)
    wx.navigateTo({
      url: '/pages/modify/modify?id=' + e.currentTarget.dataset.id,
    })
  },
  daonate(e){
    wx.navigateTo({
      url: '/pages/daonatemsg/daonatemsg?id=' + e.currentTarget.dataset.id,
    })
  }

})