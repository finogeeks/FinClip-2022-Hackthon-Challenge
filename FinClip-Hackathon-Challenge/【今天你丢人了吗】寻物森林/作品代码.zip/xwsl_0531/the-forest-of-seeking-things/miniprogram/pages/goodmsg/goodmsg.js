// pages/msg1/msg1.js
const DB = wx.cloud.database({
  env: 'cloud1-2g7s81h60f3fd184'
}).collection("Tweet")
let title = ""
let others = ""
var pic =""
var id=''

Page({
  data:{
   topic:[],
   onlyid:{
     tip:"520891"
   }
  },

//上传图片
f0: function(event){
  let that = this;
  var that_ = this;
  wx.chooseImage({
    count: 1,
    sizeType: ['original', 'compressed'],
    sourceType: ['album', 'camera'],
    success: function(res){
      console.log("选择成功",res)
      that_.setData({
        src:res.tempFilePaths[0],
        src_list:res.tempFilePaths,
        judge:res.tempFilePaths["length"]   
       })
      var src_list=res.tempFilePaths
      console.log("src_list",src_list)
      src_list.forEach((item,idx)=>{
        var fileName=Date.now()+"_"+idx;
        that.uploadImg(fileName,item)
      })
      },
  })
},

//上传图片到云开发
uploadImg(fileUrl,path){
  wx.cloud.uploadFile({
    cloudPath: fileUrl+'example.png', // 上传至云端的路径
    filePath: path, // 小程序临时文件路径
    success: res => {
      // 返回文件 ID
      pic=res.fileID
      console.log("上传成功",res)
      console.log("照片",pic)
      console.log("cloundPath",cloundPath)
      this.setData({
        pic: res.fileID
      })
    },
    fail: console.error
  })
},

//点击预览图片
f1:function(event){
  wx.previewImage({
     current: pic, // 当前显示图片的http链接
     urls: pic, // 需要预览的图片http链接列表
    success:function(res){
      console.log("1111",res)
    }
  })
},

//获取用户输入的信息
title(event){
  console.log(event.detail.value)
  title = event.detail.value
},

others(event){
  console.log(event.detail.value)
  others = event.detail.value
},

//添加数据
addData(){
  wx.showLoading({
    title: "提交中",
  })
  if(pic=='' || pic==null) {
    wx.showToast({
      title: '信息要填写全面哟~',
      icon: 'none',
      duration: 2000     
    })
  } else {
    DB.add({
      data:{
        title:title,
        others:others,
        pic1:pic,
        dianzan:false
      },
      success(res){
        console.log("添加成功",res)
        wx.showToast({
          title: '提交成功',
          icon: 'success',
          duration: 2000
          })
        wx.reLaunch({
          url:"/pages/mom_beauty/mom_beauty",
        })
      },
      fail(res){
        console.log("添加失败",res)
        wx.showToast({
          title: '提交失败',
          icon: 'error',
          duration: 2000
          })
      },
    })
  }
},

//查询数据
getData(){
  DB.get({
    success(res){
      console.log("查询数据成功",res)
    },
    fail(res){
      console.log("查询失败",res)
    }
  })
},

godetail(e) {
  console.log(e)
  wx.navigateTo({
    url: '/pages/mom_beauty/mom_beauty?id=' + e.currentTarget.dataset.id,
  })
},

gettopic() {
  wx.cloud.database().collection("Tweet")
  .where({
    t_location:"subfield"
  })
  .get()
  .then(res => {
    console.log("获取成功",res)
    this.setData({
      topic:res.data
    })
  })
  .catch(err => {
    console.log("获取失败",err)
  })
},

gotop(e) {
  console.log(e)
  wx.showModal({
    title:"敬请期待",
    content:"话题版块仍在设计中"
  })
  // wx.navigateTo({
  //   url: '/pages/toptop/toptop?id=' + this.data.onlyid.tip
  // })
},

go_tweet(e) {
  console.log("id",e.currentTarget.dataset.id)
  id = e.currentTarget.dataset.id
  DB.doc(id)
  .get()
  .then(res=>{
    console.log("获取成功",res.data.t_url)
    wx.navigateTo({
      url: '/pages/tweet/tweet?url=' + res.data.t_url,
    })
  })
  .catch(err=>{
    console.log("获取失败",err)
  })
},

  onLoad: function (options) {
    this.gettopic()
  },

})