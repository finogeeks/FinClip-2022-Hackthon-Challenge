// pages/storage/storage.js
var pic =""
var pic_list = new Array();
var app = getApp()

const DB = wx.cloud.database().collection("lost_storage")


let name = ""
// let moren_lab1 = ""
// let moren_lab2 = ""
// let lab = []
// var call=""
var named=""
// var award=""
var lost_name=""
// var lost_moren_lab1=""
// var lost_moren_lab2=""
var category_lab_msg = ""
var lost_number = ""
var get_time = ""
var get_place = ""
var other =""
var src=""
let pic1 = ""
var altimg = ""
var category_title = ""
var category_name = ""
var id = ''

Page({
  data: {
    good:{},
    img_f1:[],
    lost_name:"物品名称",
    category_lab_msg : "失物分类",
    lost_number:"物品编号",
    get_time:"拾遗时间",
    get_place:"拾遗地点",
    other:"其他描述",
    pic_src:"",
    date:new Date(),
    judge:"",
    open_id:[],
    datab:[],
  },

  //上传图片
  f0: function(event){
    let that = this;
    var that_ = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function(res){
        console.log("选择成功",res)
        that_.setData({
          src:res.tempFilePaths[0],
          src_list:res.tempFilePaths,
          judge:res.tempFilePaths["length"]   
         })
        var src_list=res.tempFilePaths
        // var judge=res.tempFilePaths["length"]
        console.log("src_list",src_list)
        src_list.forEach((item,idx)=>{
          var fileName=Date.now()+"_"+idx;
          that.uploadImg(fileName,item)
        })
        },
    })
    that.uploadImg()
    
  },
  //上传图片到云开发
uploadImg(fileUrl,path){
  var that = this
  wx.cloud.uploadFile({
    cloudPath: fileUrl+'example.png', // 上传至云端的路径
    filePath: path, // 小程序临时文件路径
    success: res => {
      // 返回文件 ID
      pic=res.fileID
      // pic_list.push(res.fileID)
       console.log("上传成功",res)
       this.setData({
        img_f1:res.fileID
      })
       console.log("照片",pic)
      //  setTimeout(function () {
      //   that.get_pichttp(pic)
      //  }, 1000) //延迟时间 这里是1秒
      console.log("cloundPath",cloundPath)
      // pic=res.fileID
      // console.log("pic",res.fileID)
      this.setData({
        pic: res.fileID
      })    
    },
    fail: console.error
  })

},
//点击预览图片
f1:function(event){
  let currentUrl = this.data.img_f1
  var dataArray = [];
  dataArray[0] = currentUrl
  wx.previewImage({
     current: dataArray[0], // 当前显示图片的http链接
     urls: dataArray, // 需要预览的图片http链接列表
    success:function(res){
      console.log("1111",res)
    }
  })
},

name(event){
  console.log(event.detail.value)
  lost_name = event.detail.value
  this.setData({
    lost_name:lost_name
  })
},

category(e){
  var that = this
  wx.navigateTo({
    url: '../../pages/category_add/category_add',
  //   success(res){
  //   that.setData({
  //     category_lab_msg = getApp().globalData.globalData_lost_time
  // })
  // }
  })
  // var category_lab_msg = getApp().globalData.globalData_lost_time
  },

number(event){
    console.log(event.detail.value)
    lost_number = event.detail.value
  this.setData({
    lost_number:lost_number
  })
},

time(event){
  console.log(event.detail.value)
  get_time = event.detail.value
this.setData({
  get_time:get_time
})
},

place(event){
  console.log(event.detail.value)
  get_place = event.detail.value
this.setData({
  get_place:get_place  
})
},

other(event){
  console.log(event.detail.value)
  other = event.detail.value
this.setData({
  other:other  
})
},
  addData_last() {
    if (lost_name=='' || lost_name==null || pic=='' || pic==null ) {
      wx.showToast({
        title: '信息都要填写哟~',
        icon: 'none',
        duration: 2000 
      })
    } else {
    // console.log("losttime",getApp().globalData.globalData_lost_time)
    wx.showLoading({
      title: "提交中",
    })
    DB.add({
      data:{
        name:this.data.lost_name, 
        lost_number:this.data.lost_number, 
        get_time:this.data.get_time, 
        get_place:this.data.get_place, 
        other:this.data.other,
        pic1:pic,
        category_lab_msg:getApp().globalData.globalData_category_value,
      //  named:named,
        count:this.data.count,
        audit:false
      },
      success(res){
        console.log("添加成功",res)
        wx.showToast({
          title: '提交成功',
          icon: 'success',
          duration: 2000
          })
          
        //   info={
        //     openid:this.data.openid,
        //     count:this.data.count
        //   },
        //  this.data.infos.push(info)
        //  that.setData({
        //    infos:this.data.infos
        //  })
        wx.navigateTo({
          url: '/pages/station/station',
        })

      },
      fail(res){
        console.log("添加失败",res)
        wx.showToast({
          title: '提交失败',
          icon: 'error',
          duration: 2000
          })
      },
    })
    }
 
  },


  //修改数据
upData:function(e){
  console.log("losttime",getApp().globalData.globalData_lost_time)
  wx.showModal({
    title:"提示",
    content:"是否确认修改信息",
    success:(res)=> {
      console.log(res)
      if (res.confirm) {
        var that = this
        that.updata_func()
      }
      else if (res.cancel) {
        console.log("取消",)
      }
    }
  })
},

    updata_func() {
      wx.cloud.database().collection('lost_storage')
      .doc(id)
      .update({
        data:{
          get_time:get_time,
          get_place:get_place,
          lost_number:lost_number,
          name:lost_name, 
          other:other,
          pic1:pic_list[0],
          category_lab_msg:getApp().globalData.globalData_category_value,
        },
          success(res){
            console.log("添加成功",res)
            wx.showToast({
              title: '提交成功',
              icon: 'success',
              duration: 2000
            })
            wx.navigateBack({
              url:'/pages/station/station?id=' + id
            })
          },
          fail(res){
            console.log("添加失败",res)
            wx.showToast({
              title: '提交失败',
              icon: 'error',
              duration: 2000
              })
          },
        })
},

//删除数据
delete_data() {
  wx.showModal({
    title:"提示",
    content:"是否确定失物以找回并删除该发布信息",
    success(res) {
      console.log(res)
      if (res.confirm) {
        DB.doc(id).remove({})
        .then(res=>{
          console.log("删除成功",res)
         wx.navigateBack({
           url:'/pages/station/station?id=' + id
         })
        })
        .catch(err =>{
          console.log("删除失败",err)
        })
      }
    }
  })
},

alter_pic() {
  console.log("图片",this.data.alt_img)
  let cloud_img = this.data.alt_img
  wx.cloud.deleteFile({
    fileList: [cloud_img],
    success: res => {
      console.log(res.fileList)
    },
    fail: console.error
  })
},

  onLoad(option) {
    other = this.data.good.other
    lost_name = this.data.good.name
    get_time = this.data.good.get_time
    get_place = this.data.good.get_place
    lost_number = this.data.good.lost_number
    altimg = this.data.good.pic1
    console.log('station传值',option.id)
    console.log('lost_name',get_time)
    id = option.id
    this.getDetail()
  },
  
  getDetail() {
    wx.cloud.database().collection('lost_storage')
      .doc(id)
      .get()
      .then(res => {
        console.log('物品查询成功',res)
        this.setData({
          good:res.data,
        })
      })
      .catch(res => {
        console.error('物品查询失败',res)
      })
  },

  onShow: function () {
    this.setData({
      category_lab_msg_name : getApp().globalData.globalData_category_value.name,
      category_lab_msg_title : getApp().globalData.globalData_category_value.title,
      category_lab_msg : getApp().globalData.globalData_category_value.name+" · "+getApp().globalData.globalData_category_value.title
    })
  },

})