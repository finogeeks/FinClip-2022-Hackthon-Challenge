// pages/banner_t/banner_t.js
var src_0=""
var src_1=""
var src_2=""
var pic =""

const DB = wx.cloud.database({
  env: 'cloud1-2g7s81h60f3fd184'
}).collection("Tweet")

Page({
  data: {
    img_f1:[],
    judge_0:"",
    judge_1:"",
    judge_2:"",
    tweet_url_0:"",
    tweet_url_1:"",
    tweet_url_2:"",
    tweet_con:{},
    src_0:"",
    src_1:"",
    src_2:"",
  },

  onLoad() {
    this.get_tweet()
  },

  get_tweet() {
    DB.where({
      t_location:"Banner",
    })
    .get()
    .then(res=>{
      console.log("首页推文信息获取成功",res)
      this.setData({
        tweet_con:res.data
      })
    })
    .catch(err=>{
      console.log(err)
    })
  },

  f0: function(event){
    let that = this;
    var that_ = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function(res){
        console.log("选择成功",res)
        that_.setData({
          src_0:res.tempFilePaths[0],
          src_list_0:res.tempFilePaths,
          judge_0:res.tempFilePaths["length"]   
         })
        var src_list_0=res.tempFilePaths
        console.log("src_list)",src_list_0)
        src_list_0.forEach((item,idx)=>{
          var fileName=Date.now()+"_"+idx;
          that.uploadImg(fileName,item)
        })
        },
    })
    that.uploadImg()
  },

  f1: function(event){
    let that = this;
    var that_ = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function(res){
        console.log("选择成功",res)
        that_.setData({
          src_1:res.tempFilePaths[0],
          src_list_1:res.tempFilePaths,
          judge_1:res.tempFilePaths["length"]   
         })
        var src_list_1=res.tempFilePaths
        console.log("src_list",src_list_1)
        src_list_1.forEach((item,idx)=>{
          var fileName=Date.now()+"_"+idx;
          that.uploadImg(fileName,item)
        })
        },
    })
    that.uploadImg()
  },

  f2: function(event){
    let that = this;
    var that_ = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function(res){
        console.log("选择成功",res)
        that_.setData({
          src_2:res.tempFilePaths[0],
          src_list_2:res.tempFilePaths,
          judge_2:res.tempFilePaths["length"]   
         })
        var src_list_2=res.tempFilePaths
        console.log("src_list",src_list_2)
        src_list_2.forEach((item,idx)=>{
          var fileName=Date.now()+"_"+idx;
          that.uploadImg(fileName,item)
        })
        },
    })
    that.uploadImg()
  },

  //上传图片到云开发
uploadImg(fileUrl,path){
  var that = this
  wx.cloud.uploadFile({
    cloudPath: fileUrl+'example.png',
    filePath: path,
    success: res => {
      pic=res.fileID
       console.log("上传成功",res)
       that.setData({
        img_f1:res.fileID
      })
      console.log("照片",pic)
      console.log("cloundPath",cloundPath)
      that.setData({
        pic: res.fileID
      })    
    },
    fail: console.error
  })
},

con_url_0(e) {
  console.log("链接",e.detail.value)
  this.setData({
    tweet_url_0:e.detail.value
  })
},

con_url_1(e) {
  console.log("链接",e.detail.value)
  this.setData({
    tweet_url_1:e.detail.value
  })
},

con_url_2(e) {
  console.log("链接",e.detail.value)
  this.setData({
    tweet_url_2:e.detail.value
  })
},

update_tweet_0() {
  var id_0 = "2d44d6c2610e82e103773d0d129d3720"
  wx.showModal({
    title:"提示",
    content:"是否更新Banner-0栏位信息",
    success:(res)=> {
      console.log(res)
      if (res.confirm && !this.data.tweet_url_0=="" && !this.data.src_0=="") {
        DB.doc(id_0)
        .update({
          data:{
            t_url:this.data.tweet_url_0,
            t_pic:this.data.src_0
          }
        }).then(res=>{
          console.log('更新成功',res)
          wx.showToast({
            title: '更新成功',
            duration: 600
          })
        }).catch(err=>{
          console.log('更新失败',err)
        })
      } else {
        wx.showToast({
          title: '请完整填写两项',
          duration: 2000
        })
      }
    }
  })
},

update_tweet_1() {
  var id_1 = "8937eaa9610e83b9032342b823c4a8b6"
  wx.showModal({
    title:"提示",
    content:"是否更新Banner-1栏位信息",
    success:(res)=> {
      console.log(res)
      if (res.confirm && !this.data.tweet_url_1=="" && !this.data.src_1=="") {
        DB.doc(id_1)
        .update({
          data:{
            t_url:this.data.tweet_url_1,
            t_pic:this.data.src_1
          }
        }).then(res=>{
          console.log('更新成功',res)
          wx.showToast({
            title: '更新成功',
            duration: 600
          })
        }).catch(err=>{
          console.log('更新失败',err)
        })
      } else {
        wx.showToast({
          title: '请完整填写两项',
          duration: 2000
        })
      }
    }
  })
},

update_tweet_2() {
  var id_2 = "2d44d6c2610e84340377c1f93b26166d"
  wx.showModal({
    title:"提示",
    content:"是否更新Banner-2栏位信息",
    success:(res)=> {
      console.log(res)
      if (res.confirm && !this.data.tweet_url_2=="" && !this.data.src_2=="") {
        DB.doc(id_2)
        .update({
          data:{
            t_url:this.data.tweet_url_2,
            t_pic:this.data.src_2
          }
        }).then(res=>{
          console.log('更新成功',res)
          wx.showToast({
            title: '更新成功',
            duration: 600
          })
        }).catch(err=>{
          console.log('更新失败',err)
        })
      } else {
        wx.showToast({
          title: '请完整填写两项',
          duration: 2000
        })
      }
    }
  })
},

})