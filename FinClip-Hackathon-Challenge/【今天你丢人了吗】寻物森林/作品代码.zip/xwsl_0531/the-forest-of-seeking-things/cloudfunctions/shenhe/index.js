// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: 'cloud1-2g7s81h60f3fd184'
})

// 云函数入口函数
exports.main = async (event, context) => {
  try {
    const result = await cloud.openapi.subscribeMessage.send({
      touser: event.openid, // 推送用户
      page: 'pages/shouye/shouye', // 跳转到小程序
      data: { //推送内容
        phrase1: {
          value: event.result
        },
        thing2: {
          value: event.name
        },
        thing7: {
          value: event.remark
        },
      },
      templateId: "09jU3ntZuIv7MBPTrJJA-gcupjdYTW6ZhjZyYb68bwg" //模板id
    })
    console.log(result)
    return result
  } catch (err) {
    console.log(err)
    return err
  }
}