// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  const cloud = require('wx-server-sdk')
cloud.init({
  env: 'cloud1-2g7s81h60f3fd184'
})

exports.main = async (event, context) => {
  const fileList = ['cloud://xxx', 'cloud://yyy']
  const result = await cloud.getTempFileURL({
    fileList: fileList,
  })
  return result.fileList
}
}