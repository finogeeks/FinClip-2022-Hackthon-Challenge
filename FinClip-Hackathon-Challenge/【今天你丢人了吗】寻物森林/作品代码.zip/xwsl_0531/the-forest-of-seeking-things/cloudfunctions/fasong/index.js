// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: 'cloud1-2g7s81h60f3fd184'
})

// 云函数入口函数
exports.main = async(event,context) => {
  try {
    const result = await cloud.openapi.subscribeMessage.send({
      touser: event.openid, // 推送用户
      page: 'pages/shouye/shouye', // 跳转到小程序
      data: { //推送内容
        thing1: {
          value: event.name
        },
        phone_number3: {
          value: event.contact
        },
        thing4: {
          value: event.place
        },
        name2: {
          value: event.remark
        },
      },
      templateId: "QPLrrmYm_Kt8giQiZHLJhPW-wQXxy5a4CrwgNSpMZe4" //模板id
    })
    console.log(result)
    return result
  } catch (err) {
    console.log(err)
    return err
  }
}