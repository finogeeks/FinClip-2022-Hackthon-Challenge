// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: 'cloud1-2g7s81h60f3fd184'
})

// 云函数入口函数
exports.main = async (event, context) => {
  return await cloud.database().collection('try_5-10').where({
    type:"丢失",
    audit_res:"通过"
  })
  .skip(event.len)
  .limit(event.pageNum)
  .get()
}