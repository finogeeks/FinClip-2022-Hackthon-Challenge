// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: "cloud1-2g7s81h60f3fd184"
})

// 云函数入口函数

exports.main = async (event, context) => {
  try {
    console.log('event.text',event.text)
    const reason =  await cloud.openapi.security.msgSecCheck({
      content:event.text
    })
    return reason
  }
  catch (err) {
    console.log("返回结果",err)
    return err
  }
}